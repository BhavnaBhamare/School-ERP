package com.model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Admin;
import com.pojo.Admission;
import com.pojo.Announcement;
import com.pojo.Book;
import com.pojo.Bookfine;
import com.pojo.Bookissuestudent;
import com.pojo.Bookissueteacher;
import com.pojo.Bus;
import com.pojo.Busstatus;
import com.pojo.Busstudent;
import com.pojo.Candidate;
import com.pojo.Candidateans;
import com.pojo.Career;
import com.pojo.Classs;
import com.pojo.Classsmart;
import com.pojo.Comment;
import com.pojo.Driver;
import com.pojo.Employee;
import com.pojo.Employeeattendance;
import com.pojo.Exampaper;
import com.pojo.Examtimetable;
import com.pojo.Fee;
import com.pojo.Homework;
import com.pojo.Homeworkcomplete;
import com.pojo.Hostel;
import com.pojo.Leaveemployee;
import com.pojo.Leavestudent;
import com.pojo.Leaveteacher;
import com.pojo.Lectureattendance;
import com.pojo.Lecturetimetable;
import com.pojo.Offlineexam;
import com.pojo.Offlineexamresult;
import com.pojo.Parent;
import com.pojo.Product;
import com.pojo.Productorder;
import com.pojo.Productpurchase;
import com.pojo.Proxylecture;
import com.pojo.Reviewstaff;
import com.pojo.Reviewstudent;
import com.pojo.Route;
import com.pojo.Salary;
import com.pojo.Scholarshipreq;
import com.pojo.Score;
import com.pojo.Sport;
import com.pojo.Sportequipment;
import com.pojo.Student;
import com.pojo.Studenthostel;
import com.pojo.Subject;
import com.pojo.Subjectsyllabus;
import com.pojo.Teacher;
import com.pojo.Teacherattendance;
import com.pojo.Testseries;
import com.pojo.Tournament;
import com.pojo.Videotutorial;
import com.pojo.Visitormeeting;
import com.pojo.Visitors;

public class BLManager {
	SessionFactory sf = new Configuration().configure().buildSessionFactory();
	public Candidateans SearchByCidQnoCandidateAns(Candidate cd,String questionno)
	{
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Candidateans.class);
		c.add(Restrictions.eq("candidate", cd));
		c.add(Restrictions.eq("questionno", questionno));
		Candidateans ca=(Candidateans)c.uniqueResult();
		return ca;
	}
	
	public boolean isAttempted(Candidate cd,String questionno)
	{
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Candidateans.class);
		c.add(Restrictions.eq("candidate",cd));
		c.add(Restrictions.eq("questionno", questionno));
		List<Candidateans> calist=c.list();
		if(calist.isEmpty())
			return false;
		else
			return true;
	}

	public void SaveCandidateans(Candidateans ca)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(ca);
		tr.commit();
		s.close();
	}	
	
	public void SaveExampaper(Exampaper e)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(e);
		tr.commit();
		s.close();
	}
	
	public void SaveScore(Score sc)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(sc);
		tr.commit();
		s.close();
	}
	
	public void SaveStudent(Student st)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(st);
		tr.commit();
		s.close();
	}	
	
	public void SaveTeacher(Teacher t)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(t);
		tr.commit();
		s.close();
	}
	
	public void SaveTestseries(Testseries ts)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.save(ts);
		tr.commit();
		s.close();
	}	
	
	public List<Exampaper> prepareExam(Candidate c)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Exampaper.class);
		Testseries tst=c.getTestseries();
		
		cr.add(Restrictions.eq("std", c.getStandard()));
		cr.add(Restrictions.eq("testseries", tst));
		
		List<Exampaper> exlist=cr.list();
		return exlist;
	}

	public List<Candidateans> getAllCandidateAnswers(Candidate c)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Candidateans.class);
		cr.add(Restrictions.eq("candidate", c));
		List<Candidateans> calist = cr.list();
		return calist;
	}
	
	public List<Candidate> ListAllCandidate()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Candidate.class);
		List<Candidate> candidatelist=cr.list();
		return candidatelist;
	}
	
	public List<Candidateans> ListAllCandidateans()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Candidateans.class);
		List<Candidateans> candidateanslist=cr.list();
		return candidateanslist;
	}

	public List<Exampaper> ListAllExampaper()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Exampaper.class);
		List<Exampaper> exampaperlist=cr.list();
		return exampaperlist;
	}
	
	public List<Score> ListAllScore()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Score.class);
		List<Score> scorelist=cr.list();
		return scorelist;
	}
	
	public List<Student> ListAllStudent()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Student.class);
		List<Student> studentlist=cr.list();
		return studentlist;
	}
	
	public List<Teacher> ListAllTeachers()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Teacher.class);
		List<Teacher> teacherlist=cr.list();
		return teacherlist;
	}
	
	public List<Testseries> ListAllTestseries()
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Testseries.class);
		List<Testseries> testserieslist=cr.list();
		return testserieslist;
	}	

	public Candidate SearchCandidateById(int cid)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Candidate.class);
		cr.add(Restrictions.eq("cid", cid));
		Candidate c=(Candidate)cr.uniqueResult();
		return c;
	}
	
	public Exampaper SearchExampaperById(int eid)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Exampaper.class);
		cr.add(Restrictions.eq("eid", eid));
		Exampaper c=(Exampaper)cr.uniqueResult();
		return c;
	}	
	
	public Student SearchStudentById(int sid)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Student.class);
		cr.add(Restrictions.eq("sid", sid));
		Student sc=(Student)cr.uniqueResult();
		return sc;
	}	
	
	public Teacher SearchTeacherById(int tid)
	{
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("tid", tid));
		Teacher t=(Teacher)cr.uniqueResult();
		return t;
	}

	public void UpdateExampaper(Exampaper e)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.update(e);
		tr.commit();
		s.close();
	}	
	
	public void DeleteCandidateans(Candidateans c)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(c);
		tr.commit();
		s.close();
	}	
	
	public void DeleteExampaper(Exampaper e)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(e);
		tr.commit();
		s.close();
	}	
	
	public void DeleteScore(Score sc)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(sc);
		tr.commit();
		s.close();
	}	
	
	public void DeleteStudent(Student st)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(st);
		tr.commit();
		s.close();
	}		
	
	public void DeleteTeacher(Teacher t)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(tr);
		tr.commit();
		s.close();
	}
	
	public void DeleteTTestseries(Testseries t)
	{
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
		s.delete(tr);
		tr.commit();
		s.close();
	}
	
	public Student getStudentByLogname(String logname)
	{
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Student.class);
		c.add(Restrictions.eq("logname", logname));
		Student st= (Student)c.uniqueResult();
		s.close();
		return st;
	}
	
	public Teacher getTeacherByLogname(String logname)
	{
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Teacher.class);
		c.add(Restrictions.eq("logname", logname));
		Teacher st= (Teacher)c.uniqueResult();
		s.close();
		return st;
	}
	
	public Testseries getTestseriesByTsname(String tsname)
	{
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Testseries.class);
		c.add(Restrictions.eq("tsname", tsname));
		Testseries ts=(Testseries)c.uniqueResult();
		s.close();
		return ts;
	}
	
	public void saveSalary(Salary s) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(s);
		t.commit();
		s1.close();
	}

	public List<Salary> getAllSalary() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Salary.class);
		List<Salary> b = cr.list();
		return b;
	}

	public Salary SearchSalaryById(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Salary.class);
		cr.add(Restrictions.eq("salid", id1));
		Salary s1 = (Salary) cr.uniqueResult();
		return s1;
	}

	public void DeleteSalary(Salary s) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.delete(s);
		t.commit();
		se.close();
	}

	public void UpdateSalary(Salary s) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.update(s);
		t.commit();
		se.close();
	}

	public void SaveTournament(Tournament t1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(t1);
		t.commit();
		s1.close();
	}

	public List<Tournament> getAllTournament() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Tournament.class);
		List<Tournament> s = cr.list();
		return s;
	}

	public Tournament SearchTournamentById(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Tournament.class);
		cr.add(Restrictions.eq("tournamentid", id1));
		Tournament e = (Tournament) cr.uniqueResult();
		return e;
	}

	public void DeleteTournament(Tournament t1) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.delete(t1);
		t.commit();
		se.close();
	}

	public List<Visitors> getAllVisitors() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Visitors.class);
		List<Visitors> s = cr.list();
		return s;
	}

	public List<Visitors> SearchVisitorslist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Visitors.class);
		List<Visitors> s = cr.list();
		return s;
	}

	public Visitors SearchByVisitorName(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Visitors.class);
		cr.add(Restrictions.eq("name", name));
		Visitors e = (Visitors) cr.uniqueResult();
		return e;
	}

	public void SaveVisitorsMeeting(Visitormeeting v1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(v1);
		t.commit();
		s1.close();
	}

	public List<Visitormeeting> getAllVisitorMeeting() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Visitormeeting.class);
		List<Visitormeeting> s = cr.list();
		return s;
	}

	public void CreateCandidateans(Candidateans cca) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cca);
		transaction.commit();
		session.close();
	}

	public List<Candidateans> GetAllCandidateans() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Candidateans.class);
		@SuppressWarnings("unchecked")
		List<Candidateans> PLlist = criteria.list();
		return PLlist;
	}

	public Candidateans GetCandidateansByAns(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Candidateans.class);
		criteria.add(Restrictions.eq("ans", ename));
		Candidateans PL = (Candidateans) criteria.uniqueResult();
		return PL;
	}

	public static Candidateans SearchCandidateansById(int s1) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session s = sf1.openSession();
		Criteria cr = s.createCriteria(Candidateans.class);
		cr.add(Restrictions.eq("caid", s1));
		Candidateans e = (Candidateans) cr.uniqueResult();
		return e;
	}

	public void UpdateCandidateans(Candidateans s) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(s);
		tr.commit();
		se.close();
	}

	public void DeleteCandidateans(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Candidateans auth = (Candidateans) s1.load(Candidateans.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateEmployeeattendance(Employeeattendance cs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cs);
		transaction.commit();
		session.close();
	}

	public void UpdateEmployeeattendance(Employeeattendance us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(us);
		transaction.commit();
		session.close();
	}

	public List<Employeeattendance> GetAllEmployeeattendance() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employeeattendance.class);
		@SuppressWarnings("unchecked")
		List<Employeeattendance> dl = criteria.list();
		return dl;
	}

	public Employeeattendance GetEmployeeattendanceByName(String tname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employeeattendance.class);
		criteria.add(Restrictions.eq("name", tname));
		Employeeattendance PL = (Employeeattendance) criteria.uniqueResult();
		return PL;
	}

	public List<Employeeattendance> SearchEmployeeattendancelist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Employeeattendance.class);
		@SuppressWarnings("unchecked")
		List<Employeeattendance> dl = cr.list();
		return dl;
	}

	public static Employeeattendance GetEmployeeattendanceById(int EmployeeattendanceId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Employeeattendance.class);
		criteria.add(Restrictions.eq("eaid", EmployeeattendanceId));
		Employeeattendance PL = (Employeeattendance) criteria.uniqueResult();
		return PL;
	}

	public void DeleteEmployeeattendance(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Employeeattendance auth = (Employeeattendance) s1.load(Employeeattendance.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateEmployee(Employee cemp) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cemp);
		transaction.commit();
		session.close();
	}

	public void UpdateEmployee(Employee uemp) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(uemp);
		transaction.commit();
		session.close();
	}

	public List<Employee> GetAllEmployee() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Employee.class);
		@SuppressWarnings("unchecked")
		List<Employee> dl = cr.list();
		return dl;
	}

	public Employee GetEmployeeByName(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("name", ename));
		Employee PL = (Employee) criteria.uniqueResult();
		return PL;
	}

	public static Employee GetEmployeeById(int EmployeeId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("eid", EmployeeId));
		Employee PL = (Employee) criteria.uniqueResult();
		return PL;
	}

	public void DeleteEmployee(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Employee auth = (Employee) s1.load(Employee.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateExamtimetable(Examtimetable crs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(crs);
		transaction.commit();
		session.close();
	}

	public void UpdateExamtimetable(Examtimetable urs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(urs);
		transaction.commit();
		session.close();
	}

	public List<Examtimetable> GetAllExamtimetable() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Examtimetable.class);
		@SuppressWarnings("unchecked")
		List<Examtimetable> dl = cr.list();
		return dl;
	}

	public static Examtimetable GetExamtimetableById(int ExamtimetableId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Examtimetable.class);
		criteria.add(Restrictions.eq("ettid", ExamtimetableId));
		Examtimetable PL = (Examtimetable) criteria.uniqueResult();
		return PL;
	}

	public void DeleteExamtimetable(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Examtimetable auth = (Examtimetable) s1.load(Examtimetable.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateFee(Fee cfee) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cfee);
		transaction.commit();
		session.close();
	}

	public void UpdateFee(Fee us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.merge(us);
		transaction.commit();
		session.close();
	}

	public Fee FeeCheck(String standard, String year) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Fee.class);
		cr.add(Restrictions.eq("standard", standard));
		cr.add(Restrictions.eq("year", year));
		Fee user = (Fee) cr.uniqueResult();

		return user;
	}

	public List<Fee> GetAllFee() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Fee.class);
		List<Fee> dl = criteria.list();
		return dl;
	}

	public Fee GetFeeByName(String pname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Fee.class);
		criteria.add(Restrictions.eq("year", pname));
		Fee PL = (Fee) criteria.uniqueResult();
		return PL;
	}

	public static Fee GetFeeById(int pid) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Fee.class);
		criteria.add(Restrictions.eq("fsid", pid));
		Fee student = (Fee) criteria.uniqueResult();
		return student;
	}

	public void DeleteFee(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Fee auth = (Fee) s1.load(Fee.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateHostel(Hostel cpl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cpl);
		transaction.commit();
		session.close();
	}

	public void UpdateHostel(Hostel upl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(upl);
		transaction.commit();
		session.close();
	}

	public List<Hostel> GetAllHostel() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Hostel.class);
		List<Hostel> PLlist = criteria.list();
		return PLlist;
	}

	public Hostel GetHostelByBed(String plname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Hostel.class);
		criteria.add(Restrictions.eq("wing", plname));
		Hostel PL = (Hostel) criteria.uniqueResult();
		return PL;
	}

	public static Hostel GetHostelById(int HostelId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Hostel.class);
		criteria.add(Restrictions.eq("hostelid", HostelId));
		Hostel PL = (Hostel) criteria.uniqueResult();
		return PL;
	}

	public void DeleteHostel(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Hostel auth = (Hostel) s1.load(Hostel.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateParent(Parent cp) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cp);
		transaction.commit();
		session.close();
	}

	public void UpdateParent(Parent us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(us);
		transaction.commit();
		session.close();
	}

	public List<Parent> GetAllParent() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Parent.class);
		List<Parent> dl = criteria.list();
		return dl;
	}

	public Parent GetParentByName(String pname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Parent.class);
		criteria.add(Restrictions.eq("fathername", pname));
		Parent PL = (Parent) criteria.uniqueResult();
		return PL;
	}

	public static Parent GetParentById(int pid) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Parent.class);
		criteria.add(Restrictions.eq("pid", pid));
		Parent student = (Parent) criteria.uniqueResult();
		return student;
	}

	public void DeleteParent(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Parent auth = (Parent) s1.load(Parent.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateProxy(Proxylecture cpl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cpl);
		transaction.commit();
		session.close();
	}

	public void UpdateProxy(Proxylecture upl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(upl);
		transaction.commit();
		session.close();
	}

	public List<Proxylecture> GetAllProxyLecture() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Proxylecture.class);
		List<Proxylecture> PLlist = criteria.list();
		return PLlist;
	}

	public Proxylecture GetProxylectureBySubjectName(String plname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Proxylecture.class);
		criteria.add(Restrictions.eq("teachername", plname));
		Proxylecture PL = (Proxylecture) criteria.uniqueResult();
		return PL;
	}

	public static Proxylecture GetProxylectureById(int ProxyLecId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Proxylecture.class);
		criteria.add(Restrictions.eq("plid", ProxyLecId));
		Proxylecture PL = (Proxylecture) criteria.uniqueResult();
		return PL;
	}

	public void DeleteProxylecture(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Proxylecture auth = (Proxylecture) s1.load(Proxylecture.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateReviewstaff(Reviewstaff crs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(crs);
		transaction.commit();
		session.close();
	}

	public void UpdateReviewstaff(Reviewstaff urs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(urs);
		transaction.commit();
		session.close();
	}

	public List<Reviewstaff> GetAllReviewstaff() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Reviewstaff.class);
		List<Reviewstaff> dl = cr.list();
		return dl;
	}

	public static Reviewstaff GetReviewstaffById(int ReviewstaffId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Reviewstaff.class);
		criteria.add(Restrictions.eq("reviewstaffid", ReviewstaffId));
		Reviewstaff PL = (Reviewstaff) criteria.uniqueResult();
		return PL;
	}

	public void DeleteReviewstaff(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Reviewstaff auth = (Reviewstaff) s1.load(Reviewstaff.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateRoute(Route cr) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cr);
		transaction.commit();
		session.close();
	}

	public List<Route> GetAllRoute() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Route.class);
		List<Route> PLlist = criteria.list();
		return PLlist;
	}

	public static Route SearchRouteById(int s1) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session s = sf1.openSession();
		Criteria cr = s.createCriteria(Route.class);
		cr.add(Restrictions.eq("routeid", s1));
		Route e = (Route) cr.uniqueResult();
		return e;
	}

	public void UpdateRoute(Route s) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(s);
		tr.commit();
		se.close();
	}

	public void DeleteRoute(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Route auth = (Route) s1.load(Route.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateScore(Score cs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cs);
		transaction.commit();
		session.close();
	}

	public List<Score> GetAllScore() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Score.class);
		List<Score> PLlist = criteria.list();
		return PLlist;
	}

	public static Score SearchScoreById(int s1) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session s = sf1.openSession();
		Criteria cr = s.createCriteria(Score.class);
		cr.add(Restrictions.eq("sid", s1));
		Score e = (Score) cr.uniqueResult();
		return e;
	}

	public void UpdateScore(Score s) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(s);
		tr.commit();
		se.close();
	}

	public void DeleteScore(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Score auth = (Score) s1.load(Score.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public Student StudentLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Student user = (Student) cr.uniqueResult();

		return user;
	}

	public void CreateStudent(Student cs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cs);
		transaction.commit();
		session.close();
	}

	public void UpdateStudent(Student us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(us);
		transaction.commit();
		session.close();
	}

	public List<Student> GetAllStudent() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> dl = criteria.list();
		return dl;
	}

	public Student GetStudentByName(String sname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("name", sname));
		Student PL = (Student) criteria.uniqueResult();
		return PL;
	}

	public static Student GetStudentById(int sid) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("sid", sid));
		Student student = (Student) criteria.uniqueResult();
		return student;
	}

	public void DeleteStudent(int id) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Student student = (Student) session.load(Student.class, new Integer(id));
		session.delete(student);
		transaction.commit();
		session.close();
	}

	public void CreateStudentHostel(Studenthostel cpl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cpl);
		transaction.commit();
		session.close();
	}

	public void UpdateStudentHostel(Studenthostel upl) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(upl);
		transaction.commit();
		session.close();
	}

	public List<Studenthostel> GetAllStudentHostel() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Studenthostel.class);
		List<Studenthostel> PLlist = criteria.list();
		return PLlist;
	}

	public Studenthostel GetStudenthostelBytName(String plname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Studenthostel.class);
		criteria.add(Restrictions.eq("", plname));
		Studenthostel PL = (Studenthostel) criteria.uniqueResult();
		return PL;
	}

	public static Studenthostel GetStudenthostelById(int SHostelId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Studenthostel.class);
		criteria.add(Restrictions.eq("shid", SHostelId));
		Studenthostel PL = (Studenthostel) criteria.uniqueResult();
		return PL;
	}

	public void DeleteStudenthostel(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Studenthostel auth = (Studenthostel) s1.load(Studenthostel.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateTeacherattendance(Teacherattendance cs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cs);
		transaction.commit();
		session.close();
	}

	public void UpdateTeacherattendance(Teacherattendance us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(us);
		transaction.commit();
		session.close();
	}

	public List<Teacherattendance> GetAllTeacherattendance() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Teacherattendance.class);
		List<Teacherattendance> dl = criteria.list();
		return dl;
	}

	public Teacherattendance GetTeacherattendanceByName(String tname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Teacherattendance.class);
		criteria.add(Restrictions.eq("name", tname));
		Teacherattendance PL = (Teacherattendance) criteria.uniqueResult();
		return PL;
	}

	public List<Teacherattendance> SearchTeacherattendancelist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacherattendance.class);
		List<Teacherattendance> dl = cr.list();
		return dl;
	}

	public static Teacherattendance GetTeacherattendanceById(int TeacherattendanceId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Teacherattendance.class);
		criteria.add(Restrictions.eq("taid", TeacherattendanceId));
		Teacherattendance PL = (Teacherattendance) criteria.uniqueResult();
		return PL;
	}

	public void DeleteTeacherattendance(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Teacherattendance auth = (Teacherattendance) s1.load(Teacherattendance.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public Teacher TeacherLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Teacher user = (Teacher) cr.uniqueResult();

		return user;
	}

	public void CreateTeacher(Teacher cs) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cs);
		transaction.commit();
		session.close();
	}

	public void UpdateTeacher(Teacher us) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(us);
		transaction.commit();
		session.close();
	}

	public List<Teacher> GetAllTeacher() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Teacher.class);
		List<Teacher> dl = criteria.list();
		return dl;
	}

	public Teacher GetTeacherByName(String tname) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Teacher.class);
		criteria.add(Restrictions.eq("name", tname));
		Teacher PL = (Teacher) criteria.uniqueResult();
		return PL;
	}

	public List<Teacher> SearchTeacherlist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		List<Teacher> dl = cr.list();
		return dl;
	}

	public static Teacher GetTeacherById(int TeacherId) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Teacher.class);
		criteria.add(Restrictions.eq("tid", TeacherId));
		Teacher PL = (Teacher) criteria.uniqueResult();
		return PL;
	}

	public void DeleteTeacher(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Teacher auth = (Teacher) s1.load(Teacher.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateTestseries(Testseries cts) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cts);
		transaction.commit();
		session.close();
	}

	public List<Testseries> GetAllTestseries() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Testseries.class);
		List<Testseries> PLlist = criteria.list();
		return PLlist;
	}

	public Testseries GetTestseriesByName(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Testseries.class);
		criteria.add(Restrictions.eq("tsname", ename));
		Testseries PL = (Testseries) criteria.uniqueResult();
		return PL;
	}

	public static Testseries SearchTestseriesById(int s1) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session s = sf1.openSession();
		Criteria cr = s.createCriteria(Testseries.class);
		cr.add(Restrictions.eq("tsid", s1));
		Testseries e = (Testseries) cr.uniqueResult();
		return e;
	}

	public void UpdateTestseries(Testseries s) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(s);
		tr.commit();
		se.close();
	}

	public void DeleteTestseries(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Testseries auth = (Testseries) s1.load(Testseries.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public void CreateVisitors(Visitors cv) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cv);
		transaction.commit();
		session.close();
	}

	public List<Visitors> GetAllVisitors() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Visitors.class);
		List<Visitors> Vlist = criteria.list();
		return Vlist;
	}

	public static Visitors GetVisitorsById(int s1) {
		SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
		Session session = sf1.openSession();
		Criteria criteria = session.createCriteria(Visitors.class);
		criteria.add(Restrictions.eq("vid", s1));
		Visitors e = (Visitors) criteria.uniqueResult();
		return e;
	}

	public void UpdateVisitors(Visitors s) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(s);
		tr.commit();
		se.close();
	}

	public void DeleteVisitors(int s) {
		Transaction trns = null;
		Session s1 = sf.openSession();
		try {
			trns = s1.beginTransaction();
			Visitors auth = (Visitors) s1.load(Visitors.class, new Integer(s));
			s1.delete(auth);
			s1.getTransaction().commit();
		} catch (RuntimeException e) {
			if (trns != null) {
				trns.rollback();
			}
			e.printStackTrace();
		} finally {
			s1.flush();
			s1.close();
		}
	}

	public Homework searchbyDivision(String division) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homework.class);
		cr.add(Restrictions.eq("division", division));
		Homework h = (Homework) cr.uniqueResult();
		return h;
	}

	public Homework searchbyStandardDivision(String standard, String division) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homework.class);
		cr.add(Restrictions.eq("standard", standard));
		cr.add(Restrictions.eq("division", division));
		Homework h = (Homework) cr.uniqueResult();
		return h;
	}

	public void updateHomeWorkComplete(Homeworkcomplete hoc) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.merge(hoc);
		t1.commit();
		s1.close();
	}

	public void deleteHomeWorkComplete(Homeworkcomplete hoc) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(hoc);
		t1.commit();
		s1.close();
	}

	public void updatelectureTimetable(Lecturetimetable ltm) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(ltm);
		t1.commit();
		s1.close();
	}

	public void deletelectureTimetable(Lecturetimetable ltm) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(ltm);
		t1.commit();
		s1.close();
	}

	public void saveOfflineExamResult(Offlineexamresult oer) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(oer);
		t1.commit();
		s1.close();
	}

	public List<Offlineexamresult> viewallOfflineExamResult() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Offlineexamresult.class);
		List<Offlineexamresult> o = cr.list();
		return o;
	}

	public Offlineexamresult searchbyid7(int id7) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Offlineexamresult.class);
		cr.add(Restrictions.eq("olerid", id7));
		Offlineexamresult o = (Offlineexamresult) cr.uniqueResult();
		return o;
	}

	public void updateOfflineExamResult(Offlineexamresult oer) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(oer);
		t1.commit();
		s1.close();
	}

	public void deleteOfflineExamResult(Offlineexamresult oer) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(oer);
		t1.commit();
		s1.close();
	}

	public void saveTestSeries(Testseries ts) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(ts);
		t1.commit();
		s1.close();
	}

	public List<Testseries> viewallTestSeries() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Testseries.class);
		List<Testseries> ts = cr.list();
		return ts;
	}

	public Testseries searchbyTSname(String tsname) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Testseries.class);
		cr.add(Restrictions.eq("tsname", tsname));
		Testseries ts = (Testseries) cr.uniqueResult();
		return ts;
	}

	public void saveOfflineExam(Offlineexam oe) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(oe);
		t1.commit();
		s1.close();
	}

	public List<Offlineexam> viewallofflineexam() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Offlineexam.class);
		List<Offlineexam> ls = cr.list();
		return ls;

	}

	public Offlineexam searchbyid8(int offexamid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Offlineexam.class);
		cr.add(Restrictions.eq("offexamid", offexamid));
		Offlineexam oe = (Offlineexam) cr.uniqueResult();
		return oe;
	}

	public void updateOfflineExam(Offlineexam oe) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(oe);
		t1.commit();
		s1.close();
	}

	public void deleteOfflineExam(Offlineexam oe) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(oe);
		t1.commit();
		s1.close();
	}

	public void saveHomework(Homework h) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(h);
		t1.commit();
		s1.close();
	}

	public Subject searchBySubName(String subname) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", subname));
		Subject s = (Subject) cr.uniqueResult();
		return s;
	}

	public List<Homework> viewHomework() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homework.class);
		List<Homework> ls = cr.list();
		return ls;
	}

	public void UpdateHomework(Homework h) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.merge(h);
		t1.commit();
		s1.close();
	}

	public void DeleteHomework(Homework h) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(h);
		t1.commit();
		s1.close();
	}

	public Homework searchById(int homeid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homework.class);
		cr.add(Restrictions.eq("homeid", homeid));
		Homework h = (Homework) cr.uniqueResult();
		return h;
	}

	public Homework searchbyStandard(String standard) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homework.class);
		cr.add(Restrictions.eq("standard", standard));
		Homework h = (Homework) cr.uniqueResult();
		return h;
	}

	public void saveHostel(Hostel ho) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(ho);
		t1.commit();
		s1.close();
	}

	public List<Hostel> viewHostel() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Hostel.class);
		List<Hostel> ls = cr.list();
		return ls;
	}

	public Hostel SearchById(int id) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Hostel.class);
		cr.add(Restrictions.eq("hostelid", id));
		Hostel h = (Hostel) cr.uniqueResult();
		return h;
	}

	public void updateHostel(Hostel ho) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.merge(ho);
		t1.commit();
		s1.close();
	}

	public void deleteHostel(Hostel ho) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(ho);
		t1.commit();
		s1.close();
	}

	public List<Employee> viewallEmployees() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Employee.class);
		List<Employee> ls = cr.list();
		return ls;
	}

	public Employee searchbyId(int id) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Employee.class);
		cr.add(Restrictions.eq("eid", id));
		Employee emp = (Employee) cr.uniqueResult();
		return emp;
	}

	public void deleteEmployee(Employee emp) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(emp);
		t1.commit();
		s1.close();
	}

	public void saveLeavesEmployee(Leaveemployee lemp) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(lemp);
		t1.commit();
		s1.close();
	}

	public Employee searchByName(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Employee.class);
		cr.add(Restrictions.eq("name", name));
		Employee emp = (Employee) cr.uniqueResult();
		return emp;
	}

	public List<Leaveemployee> viewleavesEmployee() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leaveemployee.class);
		List<Leaveemployee> le = cr.list();
		return le;
	}

	public Leaveemployee searchbyId1(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leaveemployee.class);
		cr.add(Restrictions.eq("leaveeid", id1));
		Leaveemployee lemp = (Leaveemployee) cr.uniqueResult();
		return lemp;
	}

	public void updateLeaveEmployee(Leaveemployee lemp) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(lemp);
		t1.commit();
		s1.close();
	}

	public void deleteLeaveEmployee(Leaveemployee lemp) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(lemp);
		t1.commit();
		s1.close();
	}

	public void saveParent(Parent p) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(p);
		t1.commit();
		s1.close();
	}

	public List<Parent> viewallParent() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Parent.class);
		List<Parent> l = cr.list();
		return l;
	}

	public Parent searchbyId2(int pid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Parent.class);
		cr.add(Restrictions.eq("pid", pid));
		Parent p = (Parent) cr.uniqueResult();
		return p;
	}

	public void updateParent(Parent p) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.merge(p);
		t1.commit();
		s1.close();
	}

	public void deleteParent(Parent p) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(p);
		t1.commit();
		s1.close();
	}

	public void saveFee(Fee f) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(f);
		t1.commit();
		s1.close();
	}

	public List<Fee> viewallFees() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Fee.class);
		List<Fee> fe = cr.list();
		return fe;
	}

	public void saveSubject(Subject sub) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(sub);
		t1.commit();
		s1.close();
	}

	public List<Subject> viewAllSubject() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		List<Subject> l = cr.list();
		return l;
	}

	public Subject searchById2(int subid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subid", subid));
		Subject sub = (Subject) cr.uniqueResult();
		return sub;
	}

	public void updateSubject(Subject sub) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.merge(sub);
		t1.commit();
		s1.close();
	}

	public void deleteSubject(Subject sub) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(sub);
		t1.commit();
		s1.close();
	}

	public Subject searchbySubname(String subname) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", subname));
		Subject sub = (Subject) cr.uniqueResult();
		return sub;
	}

	public void saveStudent(Student s) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(s);
		t1.commit();
		s1.close();
	}

	public List<Student> viewAllStudent() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Student.class);
		List<Student> ls = cr.list();
		return ls;
	}

	public Student searchbyStudent(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Student.class);
		cr.add(Restrictions.eq("name", name));
		Student s = (Student) cr.uniqueResult();
		return s;
	}

	public void saveHomeWorkComplete(Homeworkcomplete hoc) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(hoc);
		t1.commit();
		s1.close();
	}

	public List<Homeworkcomplete> viewHomeworkcompletes() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homeworkcomplete.class);
		List<Homeworkcomplete> ls = cr.list();
		return ls;
	}

	public Homeworkcomplete searchbyId3(int hcid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Homeworkcomplete.class);
		cr.add(Restrictions.eq("hcid", hcid));
		Homeworkcomplete hc = (Homeworkcomplete) cr.uniqueResult();
		return hc;

	}

	public void saveleaveStudent(Leavestudent lst) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(lst);
		t1.commit();
		s1.close();
	}

	public List<Leavestudent> viewallLeaveStudent() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leavestudent.class);
		List<Leavestudent> ls = cr.list();
		return ls;
	}

	public Leavestudent searchbyid3(int leavesid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leavestudent.class);
		cr.add(Restrictions.eq("leavesid", leavesid));
		Leavestudent ls = (Leavestudent) cr.uniqueResult();
		return ls;
	}

	public void updateLeaveStudent(Leavestudent lst) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(lst);
		t1.commit();
		s1.close();
	}

	public void deleteLeaveStudent(Leavestudent lst) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(lst);
		t1.commit();
		s1.close();
	}

	public void saveTeacher(Teacher t) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(t);
		t1.commit();
		s1.close();
	}

	public List<Teacher> viewallTeacher() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Teacher.class);
		List<Teacher> ls = cr.list();
		return ls;
	}

	public void saveLeaveTeacher(Leaveteacher lt) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(lt);
		t1.commit();
		s1.close();
	}

	public Teacher searchTeacherByName(String name1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("name", name1));
		Teacher t = (Teacher) cr.uniqueResult();
		return t;
	}

	public List<Leaveteacher> viewallLeaveTeachers() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leaveteacher.class);
		@SuppressWarnings("unchecked")
		List<Leaveteacher> ls = cr.list();
		return ls;
	}

	public Leaveteacher searchbyid4(int id4) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Leaveteacher.class);
		cr.add(Restrictions.eq("leavetid", id4));
		Leaveteacher lt = (Leaveteacher) cr.uniqueResult();
		return lt;
	}

	public void updateLeaveTeacher(Leaveteacher lt) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.update(lt);
		t1.commit();
		s1.close();
	}

	public void deleteLeaveTeacher(Leaveteacher lt) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(lt);
		t1.commit();
		s1.close();
	}

	public void saveLectureAttendance(Lectureattendance lat) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(lat);
		t1.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Lectureattendance> viewlectureattendance() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lectureattendance.class);
		List<Lectureattendance> ls = cr.list();
		return ls;
	}

	public Lectureattendance searchbyid5(int id5) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lectureattendance.class);
		cr.add(Restrictions.eq("laid", id5));
		Lectureattendance lat = (Lectureattendance) cr.uniqueResult();
		return lat;
	}

	public void updateLectureAttendance(Lectureattendance lat) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(lat);
		t1.commit();
		s1.close();
	}

	public void deleteLectureAttendance(Lectureattendance lat) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.delete(lat);
		t1.commit();
		s1.close();
	}

	public void saveLectureTimetable(Lecturetimetable ltm) {
		Session s1 = sf.openSession();
		Transaction t1 = s1.beginTransaction();
		s1.save(ltm);
		t1.commit();
		s1.close();
	}

	public List<Lecturetimetable> viewallLectureTimetable() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lecturetimetable.class);
		List<Lecturetimetable> ls = cr.list();
		return ls;
	}

	public Lecturetimetable searchbyid6(int id6) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lecturetimetable.class);
		cr.add(Restrictions.eq("ltid", id6));
		Lecturetimetable ltm = (Lecturetimetable) cr.uniqueResult();
		return ltm;
	}

	public void saveAnnouncement(Announcement a) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(a);
		tr.commit();
		se.close();

	}

	public List<Announcement> getAllAnnouncement() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Announcement.class);
		@SuppressWarnings("unchecked")
		List<Announcement> a = cr.list();
		return a;
	}

	public Announcement SearchByAnnouncementId(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Announcement.class);
		cr.add(Restrictions.eq("id", id1));
		Announcement a = (Announcement) cr.uniqueResult();
		return a;

	}

	public void DeleteAnnouncement(Announcement a) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.delete(a);
		tr.commit();
		se.close();

	}

	public void UpdateAnnouncement(Announcement a) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.update(a);
		t.commit();
		se.close();

	}

	public List<Book> searchlist() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Book.class);
		List<Book> dl = cr.list();
		return dl;
	}

	public void saveBook(Book b) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(b);
		tr.commit();
		se.close();
	}

	public List<Book> getAllBook() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Book.class);
		List<Book> b = cr.list();
		return b;
	}

	public Book SearchBookById(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Book.class);
		cr.add(Restrictions.eq("id", id1));
		Book e = (Book) cr.uniqueResult();
		return e;
	}

	public void DeleteBook(Book b) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.delete(b);
		t.commit();
		se.close();

	}

	public void updateBook(Book b) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.update(b);
		t.commit();
		se.close();

	}

	public Subject searchbySubName(String subname) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", subname));
		Subject s1 = (Subject) cr.uniqueResult();
		return s1;
	}

	public List<Student> searchlist1() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Student.class);
		List<Student> dl = cr.list();
		return dl;
	}

	public Student searchbyUniqueId(String uniqueid) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("uniqueid", uniqueid));
		Student e = (Student) cr.uniqueResult();
		return e;
	}

	public void saveBookfine(Bookfine b) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(b);
		tr.commit();
		se.close();
	}

	public List<Bookfine> getAllBookFine() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Bookfine.class);
		List<Bookfine> b = cr.list();
		return b;
	}

	public Bookfine SearchBookfineById(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bookfine.class);
		cr.add(Restrictions.eq("bfid", id1));
		Bookfine b = (Bookfine) cr.uniqueResult();
		return b;
	}

	public void DeleteClass(Bookfine b) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.delete(b);
		tr.commit();
		se.close();

	}

	public void updateBookFine(Bookfine b) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(b);
		tr.commit();
		se.close();
	}

	public List<Book> searchBookList() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Book.class);
		List<Book> dl = cr.list();
		return dl;
	}

	public List<Student> searchStudentList() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		List<Student> dl = cr.list();
		return dl;
	}

	public List<Bookissuestudent> getAllBookissueStudent() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bookissuestudent.class);
		@SuppressWarnings("unchecked")
		List<Bookissuestudent> e = cr.list();
		return e;
	}

	public Book searchByBoookIsbn(String isbn) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Book.class);
		cr.add(Restrictions.eq("isbn", isbn));
		Book s1 = (Book) cr.uniqueResult();
		return s1;
	}

	public Student searchByUniqueId(String uniqueid) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("uniqueid", uniqueid));
		Student s1 = (Student) cr.uniqueResult();
		return s1;
	}

	public void SaveBookIssueStudent(Bookissuestudent bi) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(bi);
		tr.commit();
		se.close();
	}

	public Bookissuestudent SearchBookIssueStudent(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bookissuestudent.class);
		cr.add(Restrictions.eq("bisid", id1));
		Bookissuestudent b = (Bookissuestudent) cr.uniqueResult();
		return b;
	}

	public void DeleteBookIssueStudent(Bookissuestudent bi) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.delete(bi);
		tr.commit();
		se.close();
	}

	public void UpdateBookIssueStudent(Bookissuestudent bi) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(bi);
		tr.commit();
		se.close();

	}

	public Teacher searchByTeachername(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("name", name));
		Teacher d = (Teacher) cr.uniqueResult();
		return d;
	}

	public void SaveBookIssueTeacher(Bookissueteacher bi1) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(bi1);
		tr.commit();
		se.close();
	}

	public List<Bookissueteacher> getAllBookissueTeacher() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bookissueteacher.class);
		@SuppressWarnings("unchecked")
		List<Bookissueteacher> e = cr.list();
		return e;
	}

	public void DeleteBookIssueTeacher(Bookissueteacher bi1) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.delete(bi1);
		tr.commit();
		se.close();
	}

	public Bookissueteacher SearchBookIssueTeacher(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bookissueteacher.class);
		cr.add(Restrictions.eq("bitid", id1));
		Bookissueteacher b = (Bookissueteacher) cr.uniqueResult();
		return b;
	}

	public void UpdateBookIssueTeacher(Bookissueteacher bi1) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(bi1);
		tr.commit();
		se.close();
	}

	public void SaveCandidateAns(Candidateans c) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(c);
		tr.commit();
		se.close();
	}

	public List<Candidateans> getAllCandidateAns() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Candidateans.class);
		List<Candidateans> b = cr.list();
		return b;
	}

	public List<Testseries> searchTestseriesList() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Testseries.class);
		List<Testseries> dl = cr.list();
		return dl;
	}

	public List<Candidate> getAllCandidate() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Candidate.class);
		@SuppressWarnings("unchecked")
		List<Candidate> e = cr.list();
		return e;
	}

	public Student searchByStudentUniqueid(String uniqueid) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("uniqueid", uniqueid));
		Student s1 = (Student) cr.uniqueResult();
		return s1;
	}

	public Testseries searchByTestseriesname(String tsname) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Testseries.class);
		cr.add(Restrictions.eq("tsname", tsname));
		Testseries s1 = (Testseries) cr.uniqueResult();
		return s1;
	}

	public void SaveCandidate(Candidate c) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(c);
		tr.commit();
		se.close();
	}

	public Candidate SearchCandidate(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Candidate.class);
		cr.add(Restrictions.eq("cid", id1));
		Candidate c = (Candidate) cr.uniqueResult();
		return c;
	}

	public void DeleteCandidate(Candidate c) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.delete(c);
		tr.commit();
		se.close();

	}

	public Student searchByStudentName(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("name", name));
		Student s1 = (Student) cr.uniqueResult();
		return s1;
	}

	public void UpdateCandidate(Candidate c) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.update(c);
		tr.commit();
		se.close();

	}

	public void saveClasss(Classs c) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(c);
		tr.commit();
		se.close();
	}

	public List<Classs> getAllClasss() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Classs.class);
		@SuppressWarnings("unchecked")
		List<Classs> b = cr.list();
		return b;
	}

	public Classs SearchClassById(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Classs.class);
		cr.add(Restrictions.eq("id", id1));
		Classs e = (Classs) cr.uniqueResult();
		return e;
	}

	public void DeleteClasss(Classs c) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.delete(c);
		t.commit();
		se.close();

	}

	public void UpdateClasss(Classs c) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.update(c);
		t.commit();
		se.close();

	}

	public void saveDriver(Driver d) {
		Session se = sf.openSession();
		Transaction tr = se.beginTransaction();
		se.save(d);
		tr.commit();
		se.close();

	}

	public List<Driver> getAllDriver() {
		Session se = sf.openSession();
		Criteria cr = se.createCriteria(Driver.class);
		@SuppressWarnings("unchecked")
		List<Driver> b = cr.list();
		return b;
	}

	public Driver SearchDriverById(int id1) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Driver.class);
		cr.add(Restrictions.eq("id", id1));
		Driver d = (Driver) cr.uniqueResult();
		return d;
	}

	public void DeleteDriver(Driver d) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.delete(d);
		t.commit();
		se.close();

	}

	public void UpdateDriver(Driver d) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.update(d);
		t.commit();
		se.close();

	}

	public void saveAdmin(Admin e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	public List<Admin> getAllAdmin() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Admin.class);
		@SuppressWarnings("unchecked")
		List<Admin> s = cr.list();
		return s;
	}

	public Admin SearchByAId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Admin.class);
		cr.add(Restrictions.eq("aid", id1));
		Admin e = (Admin) cr.uniqueResult();
		return e;
	}

	public void updateAdmin(Admin e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void deleteAdmin(Admin e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveProduct(Product e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	public List<Product> getAllProduct() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Product.class);
		@SuppressWarnings("unchecked")
		List<Product> s = cr.list();
		return s;
	}

	public Product SearchByPId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Product.class);
		cr.add(Restrictions.eq("pid", id1));
		Product e = (Product) cr.uniqueResult();
		return e;
	}

	public void updateProduct(Product e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void deleteProduct(Product e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveOrderProduct(Productorder e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	public List<Productorder> getAllOrderProduct() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Productorder.class);
		@SuppressWarnings("unchecked")
		List<Productorder> s = cr.list();
		return s;
	}

	public Productorder SearchByPOId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Productorder.class);
		cr.add(Restrictions.eq("poid", id1));
		Productorder e = (Productorder) cr.uniqueResult();
		return e;
	}

	public void deleteOrderProduct(Productorder e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void updateOrderProduct(Productorder e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void savePurchaseProduct(Productpurchase e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Productpurchase> getAllPurchaseProduct() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Productpurchase.class);
		List<Productpurchase> s = cr.list();
		return s;
	}

	public Productpurchase SearchByPPId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Productpurchase.class);
		cr.add(Restrictions.eq("ppid", id1));
		Productpurchase e = (Productpurchase) cr.uniqueResult();
		return e;
	}

	public void updatePurchaseProduct(Productpurchase e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void deletePurchaseProduct(Productpurchase e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveSport(Sport e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Sport> getAllSport() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sport.class);
		List<Sport> s = cr.list();
		return s;
	}

	public Sport SearchBySId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sport.class);
		cr.add(Restrictions.eq("sportid", id1));
		Sport e = (Sport) cr.uniqueResult();
		return e;
	}

	public Sport SearchBySName(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sport.class);
		cr.add(Restrictions.eq("sportname", name));
		Sport e = (Sport) cr.uniqueResult();
		return e;
	}

	public void updateSport(Sport e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void deleteSport(Sport e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveSportEquipment(Sportequipment e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	public Subject SearchBySubName(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", name));
		Subject e = (Subject) cr.uniqueResult();
		return e;
	}

	@SuppressWarnings("unchecked")
	public List<Sportequipment> getAllSportequipment() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sportequipment.class);
		List<Sportequipment> s = cr.list();
		return s;
	}

	@SuppressWarnings("unchecked")
	public List<Subjectsyllabus> getAllSubjectSyllabus() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subjectsyllabus.class);
		List<Subjectsyllabus> s = cr.list();
		return s;
	}

	public Sportequipment SearchBySEId(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sportequipment.class);
		cr.add(Restrictions.eq("seid", id1));
		Sportequipment e = (Sportequipment) cr.uniqueResult();
		return e;
	}

	public void updateSportEquipment(Sportequipment e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Sport> SearchSportlist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sport.class);
		List<Sport> s = cr.list();
		return s;
	}

	public void deleteSportEquipment(Sportequipment e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Teacher> getAllTeacher() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Teacher.class);
		List<Teacher> s = cr.list();
		return s;
	}

	@SuppressWarnings("unchecked")
	public List<Subject> getAllSubject() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		List<Subject> s = cr.list();
		return s;
	}

	public Subject searchbySubid(int subid) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subid", subid));
		Subject d = (Subject) cr.uniqueResult();
		return d;

	}

	public Subjectsyllabus searchbySubSid(int ssid) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subjectsyllabus.class);
		cr.add(Restrictions.eq("ssid", ssid));
		Subjectsyllabus d = (Subjectsyllabus) cr.uniqueResult();
		return d;

	}

	public void updateSubjectsyllabus(Subjectsyllabus e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void DeleteSubject(Subject e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void DeleteSubSyllabus(Subjectsyllabus e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Subject> SearchSubjectlist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Subject.class);
		List<Subject> s = cr.list();
		return s;
	}

	public Teacher searchbyTname(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("name", name));
		Teacher d = (Teacher) cr.uniqueResult();
		return d;

	}

	public Subject searchbySname(String subname) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", subname));
		Subject d = (Subject) cr.uniqueResult();
		return d;

	}

	public void saveVideo(Videotutorial e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Videotutorial> getAllVideos() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Videotutorial.class);
		List<Videotutorial> s = cr.list();
		return s;
	}

	public Videotutorial SearchByVId(int vid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Videotutorial.class);
		cr.add(Restrictions.eq("vid", vid));
		Videotutorial e = (Videotutorial) cr.uniqueResult();
		return e;
	}

	public void updateVideos(Videotutorial e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void DeleteVideos(Videotutorial e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public List<Student> SearchStudentlist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Student.class);
		@SuppressWarnings("unchecked")
		List<Student> s = cr.list();
		return s;
	}

	public Student serachByStudName(String name) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Student.class);
		cr.add(Restrictions.eq("name", name));
		Student e = (Student) cr.uniqueResult();
		return e;
	}

	public void saveReview(Reviewstudent c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	@SuppressWarnings("unchecked")
	public List<Reviewstudent> getAllReview() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Reviewstudent.class);
		List<Reviewstudent> s = cr.list();
		return s;
	}

	public Reviewstudent SearchByRSId(int reviewstudid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Reviewstudent.class);
		cr.add(Restrictions.eq("reviewstudid", reviewstudid));
		Reviewstudent e = (Reviewstudent) cr.uniqueResult();
		return e;
	}

	public Student SearchByStudId(int sid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Student.class);
		cr.add(Restrictions.eq("sid", sid));
		Student e = (Student) cr.uniqueResult();
		return e;
	}

	public void updateReview(Reviewstudent e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void DeleteReview(Reviewstudent e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveScholarship(Scholarshipreq c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	@SuppressWarnings("unchecked")
	public List<Scholarshipreq> getAllScholarship() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Scholarshipreq.class);
		List<Scholarshipreq> s = cr.list();
		return s;
	}

	public Scholarshipreq SearchByScId(int scholarqid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Scholarshipreq.class);
		cr.add(Restrictions.eq("scholarqid", scholarqid));
		Scholarshipreq e = (Scholarshipreq) cr.uniqueResult();
		return e;
	}

	public void updateScholarship(Scholarshipreq e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void DeleteScholarship(Scholarshipreq e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveSubjectsyllabus(Subjectsyllabus s) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.save(s);
		t.commit();
		se.close();
	}

	@SuppressWarnings("unchecked")
	public List<Lecturetimetable> getAllTimeTable() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lecturetimetable.class);
		List<Lecturetimetable> s = cr.list();
		return s;
	}

	public Lecturetimetable SearchByLId(int ltid) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lecturetimetable.class);
		cr.add(Restrictions.eq("ltid", ltid));
		Lecturetimetable e = (Lecturetimetable) cr.uniqueResult();
		return e;
	}

	public void updateTimeTable(Lecturetimetable e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(e);
		t.commit();
		s1.close();
	}

	public void deleteLectureTimeTable(Lecturetimetable e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(e);
		t.commit();
		s1.close();
	}

	public void saveTimeTable(Lecturetimetable e) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.save(e);
		t.commit();
		s1.close();
	}

	public Sport SearchBySEName(String sportname) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Sport.class);
		cr.add(Restrictions.eq("sportname", sportname));
		Sport e = (Sport) cr.uniqueResult();
		return e;
	}

	public void saveCareer(Career c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveBus(Bus c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveBusStudent(Busstudent c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void savelectureAttendance(Lectureattendance c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveclassSmart(Classsmart c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveComment(Comment c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveAdmission(Admission c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveEmployee(Employee c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public void saveBusStatus(Busstatus c) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		s.close();
	}

	public List<Lectureattendance> getAllLectureattendance() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Lectureattendance.class);
		List<Lectureattendance> s = cr.list();
		return s;
	}

	public List<Career> getAllCareer() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Career.class);
		List<Career> s = cr.list();
		return s;
	}

	public List<Bus> getAllBus() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Bus.class);
		List<Bus> s = cr.list();
		return s;
	}

	public List<Busstudent> getAllBustudents() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Busstudent.class);
		List<Busstudent> s = cr.list();
		return s;
	}

	public List<Busstatus> getAllBusStatus() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Busstatus.class);
		List<Busstatus> s = cr.list();
		return s;
	}

	public List<Admission> getAllAdmission() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Admission.class);
		List<Admission> s = cr.list();
		return s;
	}

	public List<Employee> getAllEmployee() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Employee.class);
		List<Employee> s = cr.list();
		return s;
	}

	public List<Classsmart> getAllClasssmart() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Classsmart.class);
		List<Classsmart> s = cr.list();
		return s;
	}

	public List<Comment> getAllComment() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Comment.class);
		List<Comment> s = cr.list();
		return s;
	}

	public Career searchbyid1(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Career.class);
		cr.add(Restrictions.eq("careerid", id));
		Career d = (Career) cr.uniqueResult();
		return d;
	}

	public Busstudent bussearchbyid1(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Busstudent.class);
		cr.add(Restrictions.eq("bsid", id));
		Busstudent d = (Busstudent) cr.uniqueResult();
		return d;
	}

	public Busstatus bssearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Busstatus.class);
		cr.add(Restrictions.eq("bsid", id));
		Busstatus d = (Busstatus) cr.uniqueResult();
		return d;
	}

	public Admission Asearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Admission.class);
		cr.add(Restrictions.eq("adid", id));
		Admission d = (Admission) cr.uniqueResult();
		return d;
	}

	public Bus bsearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bus.class);
		cr.add(Restrictions.eq("busid", id));
		Bus d = (Bus) cr.uniqueResult();
		return d;
	}

	public Lectureattendance lsearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Lectureattendance.class);
		cr.add(Restrictions.eq("laid", id));
		Lectureattendance d = (Lectureattendance) cr.uniqueResult();
		return d;
	}

	public Comment searchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Comment.class);
		cr.add(Restrictions.eq("commentid", id));
		Comment d = (Comment) cr.uniqueResult();
		return d;
	}

	public Employee esearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Employee.class);
		cr.add(Restrictions.eq("eid", id));
		Employee d = (Employee) cr.uniqueResult();
		return d;
	}

	public Classsmart csearchbyid(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Classsmart.class);
		cr.add(Restrictions.eq("scid", id));
		Classsmart d = (Classsmart) cr.uniqueResult();
		return d;
	}

	public void updateCareer(Career d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void updateBus(Bus d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void updatelectureAttendance(Lectureattendance d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void updateComment(Comment d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void UpdateAdmission(Admission d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void UpdateBusstudent(Busstudent d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void UpdateBusstatus(Busstatus d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public void updateclassSmart(Classsmart d) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.merge(d);
		t.commit();
		s1.close();
	}

	public Teacher searchby(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		cr.add(Restrictions.eq("name", name));
		Teacher d = (Teacher) cr.uniqueResult();
		return d;
	}

	public Bus statussearchby(String busno) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Bus.class);
		cr.add(Restrictions.eq("busno", busno));
		Bus d = (Bus) cr.uniqueResult();
		return d;
	}

	public Driver dsearchby(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Driver.class);
		cr.add(Restrictions.eq("dname", name));
		Driver d = (Driver) cr.uniqueResult();
		return d;
	}

	public Student Studentsearchby(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Student.class);
		cr.add(Restrictions.eq("name", name));
		Student d = (Student) cr.uniqueResult();
		return d;
	}

	public Route rsearchby(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Route.class);
		cr.add(Restrictions.eq("source", name));
		Route d = (Route) cr.uniqueResult();
		return d;
	}

	public Route rsearchby1(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Route.class);
		cr.add(Restrictions.eq("destination", name));
		Route d = (Route) cr.uniqueResult();
		return d;
	}

	public Subject searchbySubject(String name) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subject.class);
		cr.add(Restrictions.eq("subname", name));
		Subject d = (Subject) cr.uniqueResult();
		return d;
	}

	public void DeleteCareer(Career d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeleteComment(Comment d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeleteBusStudent(Busstudent d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeletelectureAttendance(Lectureattendance d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeleteEmployee(Employee d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void Deletebusstatus(Busstatus d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeletebsearchbyidComment(Comment d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void Deletebus(Bus d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeleteClass(Classsmart d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	public void DeleteAdmission(Admission d1) {
		Session s1 = sf.openSession();
		Transaction t = s1.beginTransaction();
		s1.delete(d1);
		t.commit();
		s1.close();
	}

	@SuppressWarnings("unchecked")
	public List<Route> SearchRoutelist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Route.class);
		List<Route> s = cr.list();
		return s;
	}

	@SuppressWarnings("unchecked")
	public List<Bus> SearchBuslist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Bus.class);
		List<Bus> s = cr.list();
		return s;
	}

	@SuppressWarnings("unchecked")
	public List<Driver> SearchDriverlist() {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Driver.class);
		List<Driver> s = cr.list();
		return s;
	}

	public List<Teacher> serachlist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Teacher.class);
		@SuppressWarnings("unchecked")
		List<Teacher> dl = cr.list();
		return dl;
	}

	public List<Subject> serachSubjectlist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Subject.class);
		@SuppressWarnings("unchecked")
		List<Subject> dl = cr.list();
		return dl;
	}

	public void updateRecords(Exampaper e) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.update(e);
		t.commit();
		s.close();
	}

	public void savepaper(Exampaper s) {
		Session se = sf.openSession();
		Transaction t = se.beginTransaction();
		se.save(s);
		t.commit();
		se.close();
	}

	public List<Exampaper> serachlist1() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Exampaper.class);
		@SuppressWarnings("unchecked")
		List<Exampaper> dl = cr.list();
		return dl;
	}

	public List<Exampaper> getAllExampaper() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Exampaper.class);
		@SuppressWarnings("unchecked")
		List<Exampaper> e = cr.list();
		return e;

	}

	public Exampaper searchbyid11(int id) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Exampaper.class);
		cr.add(Restrictions.eq("eid", id));
		Exampaper d = (Exampaper) cr.uniqueResult();
		return d;
	}

	public Testseries searchby1(String tsname) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Testseries.class);
		cr.add(Restrictions.eq("tsname", tsname));
		Testseries d = (Testseries) cr.uniqueResult();
		return d;

	}

	public void deleteRecords(Exampaper e) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(e);
		t.commit();
		s.close();
	}

	public List<Testseries> serachDepartlist() {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Testseries.class);
		@SuppressWarnings("unchecked")
		List<Testseries> dl = cr.list();
		return dl;
	}

	public Employee EmployeeLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Employee.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Employee user = (Employee) cr.uniqueResult();

		return user;
	}

	public Admin AdminLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Admin.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Admin user = (Admin) cr.uniqueResult();
		System.out.println(user);
		return user;
	}

	public Parent ParentLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Parent.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Parent user = (Parent) cr.uniqueResult();

		return user;
	}

	public Visitormeeting SearchVisitorsMeetingById(int id1) {
		Session s1 = sf.openSession();
		Criteria cr = s1.createCriteria(Visitormeeting.class);
		cr.add(Restrictions.eq("vmid", id1));
		Visitormeeting e = (Visitormeeting) cr.uniqueResult();
		return e;
	}

	public void UpdateVisitorMeeting(Visitormeeting v) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.update(v);
		t.commit();
		s.close();
	}

	public Driver DriverLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Driver.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Driver user = (Driver) cr.uniqueResult();

		return user;
	}

	public Hostel HostelAdminLogin(String username, String password) {
		Session s = sf.openSession();
		Criteria cr = s.createCriteria(Hostel.class);
		cr.add(Restrictions.eq("logname", username));
		cr.add(Restrictions.eq("logpass", password));
		Hostel user = (Hostel) cr.uniqueResult();

		return user;	}

}
