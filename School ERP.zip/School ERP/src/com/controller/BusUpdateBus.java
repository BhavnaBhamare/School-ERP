package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Bus;
import com.pojo.Driver;
import com.pojo.Route;

/**
 * Servlet implementation class BusUpdateBus
 */
@WebServlet("/BusUpdateBus")
public class BusUpdateBus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BusUpdateBus() {
		super();
		// TODO Auto-generated constructor stub
	}

	Bus e = new Bus();
	BLManager b = new BLManager();
	Route r = new Route();
	Driver d = new Driver();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("busid");
		int id = Integer.parseInt(id1);

		e = b.bsearchbyid(id);
		HttpSession ses = request.getSession();
		ses.setAttribute("list", e);

		response.sendRedirect("BusUpdateBus.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String no = request.getParameter("no");

		String dateofrepair = request.getParameter("dateofrepair");
		String capacity = request.getParameter("capacity");
		String source = request.getParameter("source");

		String dname = request.getParameter("dname");

		r = b.rsearchby(source);
		d = b.dsearchby(dname);

		e.setBusno(no);
		e.setDateofrepair(dateofrepair);
		e.setCapacity(capacity);
		e.setRoute(r);
		e.setDriver(d);

		b.updateBus(e);

		response.sendRedirect("BusDashboard.jsp");
	}

}
