package com.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Driver;

/**
 * Servlet implementation class BusSaveBusDriver
 */
@WebServlet("/BusSaveBusDriver")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class BusSaveBusDriver extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	private static final String SAV_DIR1 = "";
	private static final String SAV_DIR2 = "";
	private static final String SAV_DIR3 = "";

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String dname = request.getParameter("dname");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String position = request.getParameter("position");
		String gender = request.getParameter("gender");
		String age = request.getParameter("age");
		String licenceno = request.getParameter("licenceno");
		String salary = request.getParameter("salary");

		Driver d = new Driver();

		BLManager bl = new BLManager();

		d.setDname(dname);
		d.setAddress(address);
		d.setPhone(phone);
		d.setPosition(position);
		d.setGender(gender);
		d.setAge(age);
		d.setLicenceno(licenceno);
		d.setSalary(salary);

		Part photo = request.getPart("photo");
		try {
			String fileName = extractFileName(photo);
			String path = getServletContext().getRealPath(SAV_DIR + File.separator + fileName);
			d.setPhoto(fileName);
			photo.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part licence = request.getPart("licence");
		try {
			String fileName1 = extractFileName1(licence);
			String path = getServletContext().getRealPath(SAV_DIR1 + File.separator + fileName1);
			d.setLicence(fileName1);
			photo.write(SAV_DIR1 + File.separator + fileName1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part aadhar = request.getPart("aadhar");
		try {
			String fileName2 = extractFileName2(aadhar);
			String path = getServletContext().getRealPath(SAV_DIR2 + File.separator + fileName2);
			d.setAadhar(fileName2);
			photo.write(SAV_DIR2 + File.separator + fileName2);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part pan = request.getPart("panno");
		try {
			String fileName3 = extractFileName3(pan);
			String path = getServletContext().getRealPath(SAV_DIR3 + File.separator + fileName3);
			d.setPanno(fileName3);
			photo.write(SAV_DIR3 + File.separator + fileName3);
		} catch (Exception e) {
			e.printStackTrace();
		}

		bl.saveDriver(d);

		response.sendRedirect("BusDashboard.jsp");
	}

	private String extractFileName3(Part pan) {
		String contentDisp = pan.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename3")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName2(Part aadhar) {
		String contentDisp = aadhar.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename2")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName1(Part licence) {
		String contentDisp = licence.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename1")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName(Part photo) {
		String contentDisp = photo.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";

	}

}
