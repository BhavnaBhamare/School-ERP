package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Salary;

/**
 * Servlet implementation class AccountingUpdateSalary
 */
@WebServlet("/AccountingUpdateSalary")
public class AccountingUpdateSalary extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Salary s = new Salary();
	BLManager bl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String id = request.getParameter("salid");
		int id1 = Integer.parseInt(id);
		s = bl.SearchSalaryById(id1);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", s);

		response.sendRedirect("AccountingUpdateSalary.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String employeename = request.getParameter("employeename");
		String paid = request.getParameter("paid");
		String unpaid = request.getParameter("unpaid");
		String total = request.getParameter("total");
		String month = request.getParameter("month");
		String monthsalary = request.getParameter("monthsalary");

		System.out.println(monthsalary);

		// Salary s=new Salary();

		s.setEmployeename(employeename);
		s.setPaid(paid);
		s.setUnpaid(unpaid);
		s.setTotal(total);

		s.setMonth(month);
		s.setMonthsalary(monthsalary);

		bl.UpdateSalary(s);
		response.sendRedirect("AccountingDashboard.jsp");
	}

}
