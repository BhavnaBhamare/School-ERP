package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Route;

/**
 * Servlet implementation class BusUpdateRoute
 */
@WebServlet("/BusUpdateRoute")
public class BusUpdateRoute extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BusUpdateRoute() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Route route = new Route();
	BLManager rbl = new BLManager();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String RouteId = request.getParameter("routeid");
		int RId = Integer.parseInt(RouteId);
		String Source = request.getParameter("source");
		String SourceTime = request.getParameter("sourcetime");
		String Destination = request.getParameter("destination");
		String DestinationTime = request.getParameter("destinationtime");
		String StopNo = request.getParameter("stopno");

		route.setRouteid(RId);
		route.setSource(Source);
		route.setSourcetime(SourceTime);
		route.setDestination(Destination);
		route.setDestinationtime(DestinationTime);
		route.setStopno(StopNo);

		rbl.UpdateRoute(route);

		response.sendRedirect("BusDashboard.jsp");
	}

}
