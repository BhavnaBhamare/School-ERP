package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Bus;
import com.pojo.Busstudent;
import com.pojo.Driver;
import com.pojo.Route;
import com.pojo.Student;

@WebServlet("/BusSaveBusStudent")
public class BusSaveBusStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BusSaveBusStudent() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	Busstudent s = new Busstudent();

	BLManager b = new BLManager();
	Bus d = new Bus();
	Student r = new Student();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String no = request.getParameter("no");

		String name = request.getParameter("name");
		String stopname = request.getParameter("stopname");

		d = b.statussearchby(no);
		r = b.Studentsearchby(name);

		s.setBus(d);
		s.setStudent(r);
		s.setStopname(stopname);

		b.saveBusStudent(s);

		response.sendRedirect("BusDashboard.jsp");
	}

}
