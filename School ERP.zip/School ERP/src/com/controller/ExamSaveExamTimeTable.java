package com.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Examtimetable;

/**
 * Servlet implementation class ExamSaveExamTimeTable
 */
@WebServlet("/ExamSaveExamTimeTable")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class ExamSaveExamTimeTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "F:/School ERP/WebContent/Document/Exam";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExamSaveExamTimeTable() {
		super();
		// TODO Auto-generated constructor stub
	}

	Examtimetable examtimetable = new Examtimetable();
	BLManager ettbl = new BLManager();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String Standard = request.getParameter("standard");
		String Division = request.getParameter("division");
		
		Part file = request.getPart("file");
		try {
			String fileName = extractFileName(file);
			String path = getServletContext().getRealPath(SAV_DIR + File.separator + fileName);
			examtimetable.setFile(fileName);
			file.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		String Year = request.getParameter("year");

		examtimetable.setStandard(Standard);
		examtimetable.setDivision(Division);
		examtimetable.setYear(Year);

		ettbl.CreateExamtimetable(examtimetable);

		response.sendRedirect("ExamAdminDashboard.jsp");
	}
		

	private String extractFileName(Part file) {
		String contentDisp = file.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}
		

	}

	

