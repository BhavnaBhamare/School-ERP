package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Classsmart;
import com.pojo.Teacher;

/**
 * Servlet implementation class TeacherSaveClassSmart
 */
@WebServlet("/TeacherSaveClassSmart")
public class TeacherSaveClassSmart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherSaveClassSmart() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Classsmart s = new Classsmart();

	BLManager b = new BLManager();
	Teacher d = new Teacher();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String classno = request.getParameter("classno");

		String date = request.getParameter("date");
		String hours = request.getParameter("hours");
		String reason = request.getParameter("reason");
		String capacity = request.getParameter("capacity");
		String name = request.getParameter("name");

		d = b.GetTeacherByName(name);

		s.setClassno(classno);
		s.setDate(date);
		s.setHours(hours);
		s.setReason(reason);
		s.setCapacity(capacity);
		s.setTeacher(d);

		b.saveclassSmart(s);

		response.sendRedirect("TeachersDashboard.jsp");
	}

}
