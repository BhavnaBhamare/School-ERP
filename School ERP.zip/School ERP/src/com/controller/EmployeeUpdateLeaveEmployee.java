package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Leaveemployee;

/**
 * Servlet implementation class EmployeeUpdateLeaveEmployee
 */
@WebServlet("/EmployeeUpdateLeaveEmployee")
public class EmployeeUpdateLeaveEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Leaveemployee lemp = new Leaveemployee();
	BLManager bl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String leaveeid1 = request.getParameter("leaveeid");
		int id1 = Integer.parseInt(leaveeid1);

		lemp = bl.searchbyId1(id1);

		HttpSession session = request.getSession();
		session.setAttribute("list", lemp);

		response.sendRedirect("EmployeeUpdateLeaveEmployee.jsp");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		PrintWriter pw = response.getWriter();

		String status = request.getParameter("status");
		lemp.setStatus(status);

		bl.updateLeaveEmployee(lemp);

		response.sendRedirect("EmployeeDashboard.jsp");

	}

}
