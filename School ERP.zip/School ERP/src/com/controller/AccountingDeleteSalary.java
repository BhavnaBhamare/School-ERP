package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Salary;

/**
 * Servlet implementation class AccountingDeleteSalary
 */
@WebServlet("/AccountingDeleteSalary")
public class AccountingDeleteSalary extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountingDeleteSalary() {
        super();
        // TODO Auto-generated constructor stub
    }
    Salary s=new Salary();
   	BLManager bl=new BLManager();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String id=request.getParameter("salid");
		int id1=Integer.parseInt(id);
		s=bl.SearchSalaryById(id1);
		bl.DeleteSalary(s);
		response.sendRedirect("AccountingDashboard.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
