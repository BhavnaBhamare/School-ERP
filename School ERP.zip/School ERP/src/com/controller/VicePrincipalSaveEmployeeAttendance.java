package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Employee;
import com.pojo.Employeeattendance;

/**
 * Servlet implementation class VicePrincipalSaveEmployeeAttendance
 */
@WebServlet("/VicePrincipalSaveEmployeeAttendance")
public class VicePrincipalSaveEmployeeAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VicePrincipalSaveEmployeeAttendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	Employee employee = new Employee();
	BLManager bl = new BLManager();
	Employeeattendance employeeatt = new Employeeattendance();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String Months = request.getParameter("months");
		String HalfDays = request.getParameter("halfdays");
		String FullDays = request.getParameter("fulldays");
		String AbsentDays = request.getParameter("totalabsentdays");
		String Name = request.getParameter("name");

		employee = bl.GetEmployeeByName(Name);

		employeeatt.setMonths(Months);
		employeeatt.setHalfdays(HalfDays);
		employeeatt.setFulldays(FullDays);
		employeeatt.setTotalabsentdays(AbsentDays);
		employeeatt.setEmployee(employee);

		bl.CreateEmployeeattendance(employeeatt);

		response.sendRedirect("VicePrincipalDashboard.jsp");
	}

}
