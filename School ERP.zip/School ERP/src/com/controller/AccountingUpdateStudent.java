package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Fee;
import com.pojo.Parent;
import com.pojo.Student;

/**
 * Servlet implementation class AccountingUpdateStudent
 */
@WebServlet("/AccountingUpdateStudent")
public class AccountingUpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AccountingUpdateStudent() {
		super();
		// TODO Auto-generated constructor stub
	}

	Student student = new Student();
	BLManager bl = new BLManager();
	Parent parent = new Parent();
	Fee fee = new Fee();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id1 = request.getParameter("sid");
		int id = Integer.parseInt(id1);
		student = bl.SearchByStudId(id);
		System.out.println(id);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", student);

		response.sendRedirect("AccountingUploadStudentFee.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String Id = request.getParameter("sid");
		int ID = Integer.parseInt(Id);
		String Name = request.getParameter("name");
		String UniqueId = request.getParameter("uniqueid");
		String Standard = request.getParameter("standard");
		String Division = request.getParameter("division");
		String DeductionFee = request.getParameter("deductionfee");
		String Unpaid = request.getParameter("unpaid");
		String Paid = request.getParameter("paid");
		String Fine = request.getParameter("fine");
		String TotalFee = request.getParameter("totalfee");
		String Deposit = request.getParameter("deposit");
		String Year = request.getParameter("year");

		fee = bl.GetFeeByName(Year);

		student.setSid(ID);
		student.setName(Name);
		student.setUniqueid(UniqueId);
		student.setStandard(Standard);
		student.setDivision(Division);
		student.setDeductionfee(DeductionFee);
		student.setUnpaid(Unpaid);
		student.setPaid(Paid);
		student.setFine(Fine);
		student.setTotalfee(TotalFee);
		student.setDeposit(Deposit);
		student.setFee(fee);
		bl.UpdateStudent(student);

		response.sendRedirect("AccountingDashboard.jsp");
	}

}
