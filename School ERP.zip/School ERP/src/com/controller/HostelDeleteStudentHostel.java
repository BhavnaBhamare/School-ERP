package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Studenthostel;

/**
 * Servlet implementation class HostelDeleteStudentHostel
 */
@WebServlet("/HostelDeleteStudentHostel")
public class HostelDeleteStudentHostel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HostelDeleteStudentHostel() {
		super();
		// TODO Auto-generated constructor stub
	}

	BLManager bl = new BLManager();
	Studenthostel s = new Studenthostel();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Id = request.getParameter("shid");
		int ID = Integer.parseInt(Id);
		s = bl.GetStudenthostelById(ID);
		bl.DeleteStudenthostel(ID);

		response.sendRedirect("HostelAdminDashboard.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
