package com.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Teacher;

/**
 * Servlet implementation class VicePrincipalSaveTeacher
 */
@WebServlet("/VicePrincipalSaveTeacher")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class VicePrincipalSaveTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	private static final String SAV_DIR1 = "";
	private static final String SAV_DIR2 = "";
	private static final String SAV_DIR3 = "";

	Teacher teacher = new Teacher();
	BLManager tbl = new BLManager();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String Name = request.getParameter("name");
		String Post = request.getParameter("post");
		String Logname = request.getParameter("logname");
		String Logpass = request.getParameter("logpass");
		String Salary = request.getParameter("salary");
		// String Photo = request.getParameter("photo");
		// String Aadhar = request.getParameter("aadhar");
		// String Pancade = request.getParameter("pancard");
		String Gender = request.getParameter("gender");
		String Age = request.getParameter("age");
		String DOB = request.getParameter("DOB");
		String Email = request.getParameter("email");
		String Joindate = request.getParameter("joindate");
		String Subjects = request.getParameter("subjects");

		Part Photo = request.getPart("photo");
		try {
			String fileName = extractFileName(Photo);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			teacher.setPhoto(fileName);
			Photo.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part Aadhar = request.getPart("aadhar");
		try {
			String fileName = extractFileName1(Aadhar);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			teacher.setAadhar(fileName);
			Aadhar.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part Pancade = request.getPart("pancade");
		try {
			String fileName = extractFileName2(Pancade);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			teacher.setPancade(fileName);
			Pancade.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		teacher.setName(Name);
		teacher.setPost(Post);
		teacher.setLogname(Logname);
		teacher.setLogpass(Logpass);
		teacher.setSalary(Salary);
		teacher.setGender(Gender);
		teacher.setAge(Age);
		teacher.setDob(DOB);
		teacher.setEmail(Email);
		teacher.setJoindate(Joindate);
		teacher.setSubjects(Subjects);

		tbl.CreateTeacher(teacher);

		response.sendRedirect("VicePrincipalDashboard.jsp");
	}

	private String extractFileName(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName1(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName2(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}
}
