package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Classsmart;
import com.pojo.Teacher;

/**
 * Servlet implementation class TeacherUpdateClasssmart
 */
@WebServlet("/TeacherUpdateClasssmart")
public class TeacherUpdateClasssmart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherUpdateClasssmart() {
		super();
		// TODO Auto-generated constructor stub
	}

	Classsmart e = new Classsmart();
	BLManager bl = new BLManager();
	Teacher d = new Teacher();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("scid");
		int id = Integer.parseInt(id1);

		e = bl.csearchbyid(id);
		HttpSession ses = request.getSession();
		ses.setAttribute("list", e);

		response.sendRedirect("TeacherUpdateClassSmart.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String classno = request.getParameter("classno");
		String date = request.getParameter("date");
		String hours = request.getParameter("hours");
		String reason = request.getParameter("reason");
		String capacity = request.getParameter("capacity");
		String name = request.getParameter("name");

		d = bl.GetTeacherByName(name);

		e.setClassno(classno);
		e.setDate(date);
		e.setHours(hours);
		e.setReason(reason);
		e.setCapacity(capacity);
		e.setTeacher(d);

		bl.updateclassSmart(e);

		response.sendRedirect("TeachersDashboard.jsp");
	}

}
