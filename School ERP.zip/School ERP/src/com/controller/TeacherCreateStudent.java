package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Fee;
import com.pojo.Parent;
import com.pojo.Student;

/**
 * Servlet implementation class TeacherCreateStudent
 */
@WebServlet("/TeacherCreateStudent")
public class TeacherCreateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherCreateStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Student student = new Student();
	BLManager bl = new BLManager();
	Parent parent = new Parent();
	Fee fee = new Fee();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String Name = request.getParameter("name");
		String UniqueId = request.getParameter("uniqueid");
		String LogName = request.getParameter("logname");
		String LogPass = request.getParameter("logpass");
		String Standard = request.getParameter("standard");
		String Division = request.getParameter("division");
		String StdRollNo = request.getParameter("stdrollno");
		String Address = request.getParameter("address");
		String Age = request.getParameter("age");
		String DOB = request.getParameter("dob");
		String Gender = request.getParameter("gender");
		String Aadhar = request.getParameter("aadhar");
		String DeductionFee = request.getParameter("deductionfee");
		String Unpaid = request.getParameter("unpaid");
		String Paid = request.getParameter("paid");
		String Fine = request.getParameter("fine");
		String TotalFee = request.getParameter("totalfee");
		String Deposit = request.getParameter("deposit");
		String BirthCertificate = request.getParameter("birthcertificate");
		String Email = request.getParameter("email");
		String Year = request.getParameter("year");
		String PName = request.getParameter("fathername");

		fee = bl.GetFeeByName(Year);
		parent = bl.GetParentByName(PName);

		student.setName(Name);
		student.setUniqueid(UniqueId);
		student.setLogname(LogName);
		student.setLogpass(LogPass);
		student.setStandard(Standard);
		student.setDivision(Division);
		student.setStdrollno(StdRollNo);
		student.setAddress(Address);
		student.setAge(Age);
		student.setDob(DOB);
		student.setGender(Gender);
		student.setAadhar(Aadhar);
		student.setDeductionfee(DeductionFee);
		student.setUnpaid(Unpaid);
		student.setPaid(Paid);
		student.setFine(Fine);
		student.setTotalfee(TotalFee);
		student.setDeposit(Deposit);
		student.setBirthcertificate(BirthCertificate);
		student.setEmail(Email);
		student.setFee(fee);
		student.setParent(parent);

		bl.CreateStudent(student);

		response.sendRedirect("TeacherDashboard.jsp");

	}

}
