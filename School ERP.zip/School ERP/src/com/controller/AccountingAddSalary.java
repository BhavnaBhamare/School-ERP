package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Salary;

/**
 * Servlet implementation class AccountingAddSalary
 */
@WebServlet("/AccountingAddSalary")
public class AccountingAddSalary extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountingAddSalary() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String employeename=request.getParameter("employeename");
		String paid=request.getParameter("paid");
		String unpaid=request.getParameter("unpaid");
		String total=request.getParameter("total");
		String month=request.getParameter("month");
		String monthsalary=request.getParameter("monthsalary");
		
	    Salary s=new Salary();
		
		BLManager bl=new BLManager();
		
	    s.setEmployeename(employeename);
		s.setPaid(paid);
		s.setUnpaid(unpaid);
		s.setTotal(total);
		s.setMonth(month);
		s.setMonthsalary(monthsalary);
		
		bl.saveSalary(s);
		
		response.sendRedirect("AccountingDashboard.jsp");	}

}
