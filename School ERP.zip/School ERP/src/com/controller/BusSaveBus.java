package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Bus;
import com.pojo.Driver;
import com.pojo.Route;

/**
 * Servlet implementation class BusSaveBus
 */
@WebServlet("/BusSaveBus")
public class BusSaveBus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusSaveBus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Bus s = new Bus();

	BLManager b = new BLManager();
	Driver d = new Driver();
	Route r = new Route();
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String no = request.getParameter("no");

		String dateofrepair = request.getParameter("dateofrepair");
		String capacity = request.getParameter("capacity");
		String source = request.getParameter("source");

		String dname = request.getParameter("dname");

		r = b.rsearchby(source);
		d = b.dsearchby(dname);

		s.setBusno(no);
		s.setDateofrepair(dateofrepair);
		s.setCapacity(capacity);
		s.setRoute(r);
		s.setDriver(d);

		b.saveBus(s);

		response.sendRedirect("BusDashboard.jsp");
	}

}
