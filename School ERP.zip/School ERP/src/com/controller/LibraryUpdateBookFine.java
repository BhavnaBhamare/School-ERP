package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Bookfine;
import com.pojo.Student;

/**
 * Servlet implementation class LibraryUpdateBookFine
 */
@WebServlet("/LibraryUpdateBookFine")
public class LibraryUpdateBookFine extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Bookfine b = new Bookfine();
	BLManager bl = new BLManager();
	Student s = new Student();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("bfid");
		int id1 = Integer.parseInt(id);
		b = bl.SearchBookfineById(id1);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", b);

		response.sendRedirect("LibraryUpdateBookFine.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String uniqueid = request.getParameter("uniqueid");
		String due = request.getParameter("due");

		s = bl.searchbyUniqueId(uniqueid);

		b.setDue(due);
		b.setStudent(s);

		bl.updateBookFine(b);
		response.sendRedirect("LibraryAdminDashboard.jsp");
	}

}
