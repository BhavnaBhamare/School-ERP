package com.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Lecturetimetable;

/**
 * Servlet implementation class TeacherLectureAttendance
 */
@WebServlet("/TeacherSaveLectureAttendance")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class TeacherSaveLectureAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	BLManager bl = new BLManager();
	Lecturetimetable ltm = new Lecturetimetable();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String year = request.getParameter("year");
		String standard = request.getParameter("standard");
		String division = request.getParameter("division");
		Part file = request.getPart("file");

		try {
			String file1 = extractFileName(file);
			ltm.setFile(file1);
			file.write(SAV_DIR + File.separator + file1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ltm.setYear(year);
		ltm.setStandard(standard);
		ltm.setDivision(division);

		bl.saveLectureTimetable(ltm);

		response.sendRedirect("TeacherDashboard.jsp");
	}

	private String extractFileName(Part file) {
		String contentDisp = file.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
