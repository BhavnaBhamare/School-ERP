package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Lectureattendance;
import com.pojo.Subject;
import com.pojo.Teacher;

/**
 * Servlet implementation class TeacherUpdateLectureAttendance
 */
@WebServlet("/TeacherUpdateLectureAttendance")
public class TeacherUpdateLectureAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherUpdateLectureAttendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	Subject a = new Subject();
	Teacher b = new Teacher();
	Lectureattendance p = new Lectureattendance();
	BLManager bl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("laid");
		int id = Integer.parseInt(id1);

		p = bl.lsearchbyid(id);
		HttpSession ses = request.getSession();
		ses.setAttribute("list", p);

		response.sendRedirect("TeacherUpdateLectureAttendance.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String dates = request.getParameter("dates");
		String hours = request.getParameter("hours");
		String standard = request.getParameter("standard");
		String division = request.getParameter("division");

		String subname = request.getParameter("subname");
		String name = request.getParameter("name");

		String rollnospresents = request.getParameter("rollnospresents");
		String rollnoabsents = request.getParameter("rollnoabsents");

		a = bl.searchbySubject(subname);
		b = bl.searchby(name);

		p.setDates(dates);
		p.setHours(hours);
		p.setStandard(standard);
		p.setDivision(division);
		p.setSubject(a);
		p.setTeacher(b);
		p.setRollnospresents(rollnospresents);
		p.setRollnoabsents(rollnoabsents);

		bl.updatelectureAttendance(p);

		response.sendRedirect("TeacherDashboard.jsp");
	}

}
