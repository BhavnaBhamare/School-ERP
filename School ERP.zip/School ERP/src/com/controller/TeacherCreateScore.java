package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Candidate;
import com.pojo.Score;
import com.pojo.Testseries;

/**
 * Servlet implementation class TeacherCreateScore
 */
@WebServlet("/TeacherCreateScore")
public class TeacherCreateScore extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherCreateScore() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Testseries testseries = new Testseries();
	BLManager bl = new BLManager();
	Candidate candidateans = new Candidate();
	
	Score score = new Score();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String Score = request.getParameter("score");
		String Ans = request.getParameter("ans");
		String TSName = request.getParameter("tsname");

//		candidateans = bl.GetCandidateansByAns(Ans);
		testseries = bl.GetTestseriesByName(TSName);

		score.setCandidate(candidateans);
		score.setTestseries(testseries);
		score.setScore(Score);

		bl.CreateScore(score);

		response.sendRedirect("TeacherDashboard.jsp");

	}

}
