package com.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Admission;

/**
 * Servlet implementation class SaveAdmission
 */
@WebServlet("/SaveAdmission")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class SaveAdmission extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	private static final String SAV_DIR1 = "";
	private static final String SAV_DIR2 = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveAdmission() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Admission c = new Admission();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String name = request.getParameter("name");
		String sname = request.getParameter("sname");
		String fathername = request.getParameter("fathername");
		String mothername = request.getParameter("mothername");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String enquiry = request.getParameter("enquiry");

		c.setName(name);
		c.setSname(sname);
		c.setFathername(fathername);
		c.setMothername(mothername);
		c.setAddress(address);
		c.setPhone(phone);
		c.setEnquiry(enquiry);

		Part filePart = request.getPart("photo");
		try {
			String fileName = extractFileName1(filePart);
			c.setPhoto(fileName);
			filePart.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part filePart1 = request.getPart("file");
		try {
			String fileName1 = extractFileName2(filePart1);
			c.setFile(fileName1);
			filePart1.write(SAV_DIR + File.separator + fileName1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part filePart2 = request.getPart("file1");
		try {
			String fileName2 = extractFileName3(filePart2);
			c.setFile1(fileName2);
			filePart2.write(SAV_DIR + File.separator + fileName2);
		} catch (Exception e) {
			e.printStackTrace();
		}

		BLManager b = new BLManager();
		b.saveAdmission(c);

		response.sendRedirect("Index.jsp");
	}

	private String extractFileName3(Part filePart2) {
		String contentDisp = filePart2.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename2")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName2(Part filePart1) {
		String contentDisp = filePart1.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename1")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName1(Part filePart) {
		String contentDisp = filePart.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";

	}

}
