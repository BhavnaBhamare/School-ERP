package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Employee;
import com.pojo.Leaveemployee;

/**
 * Servlet implementation class EmployeeSaveReviewStaff
 */
@WebServlet("/EmployeeSaveReviewStaff")
public class EmployeeSaveReviewStaff extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeSaveReviewStaff() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Leaveemployee lemp = new Leaveemployee();
	Employee emp = new Employee();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String name = request.getParameter("name");
		String reason = request.getParameter("reason");
		String status = request.getParameter("status");
		
		emp = bl.GetEmployeeByName(name);
		
		lemp.setReason(reason);
		lemp.setStatus(status);
		lemp.setEmployee(emp);
		
		bl.saveLeavesEmployee(lemp);
		
		response.sendRedirect("EmployeeDashboard.jsp");
		
	}
}
