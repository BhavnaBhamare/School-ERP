package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Productpurchase;

/**
 * Servlet implementation class AccountingDeletePurchaseProduct
 */
@WebServlet("/AccountingDeletePurchaseProduct")
public class AccountingDeletePurchaseProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountingDeletePurchaseProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

    BLManager bl=new BLManager();
   	Productpurchase p=new Productpurchase();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("ppid");
		int id1=Integer.parseInt(id);
		p=bl.SearchByPPId(id1);
		bl.deletePurchaseProduct(p);
		response.sendRedirect("AccountingDashboard.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
