package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Homework;
import com.pojo.Subject;

/**
 * Servlet implementation class TeacherAddHomework
 */
@WebServlet("/TeacherAddHomework")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class TeacherAddHomework extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	BLManager bl = new BLManager();
	Homework ho = new Homework();
	Subject sub = new Subject();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherAddHomework() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String standard = request.getParameter("standard");
		String division = request.getParameter("division");
		Part doc = request.getPart("doc");

		try {
			String fileName = extractFileName(doc);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			ho.setDoc(fileName);
			doc.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		String subname = request.getParameter("subname");

		sub = bl.searchBySubName(subname);

		sub = bl.searchbySname(subname);

		ho.setStandard(standard);
		ho.setDivision(division);
		ho.setSubject(sub);

		bl.saveHomework(ho);

		response.sendRedirect("TeacherDashboard.jsp");

	}

	private String extractFileName(Part doc) {
		String contentDisp = doc.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
