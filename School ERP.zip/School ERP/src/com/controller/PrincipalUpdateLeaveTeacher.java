package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Leaveteacher;
import com.pojo.Teacher;

/**
 * Servlet implementation class PrincipalUpdateLeaveTeacher
 */
@WebServlet("/PrincipalUpdateLeaveTeacher")
public class PrincipalUpdateLeaveTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrincipalUpdateLeaveTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Leaveteacher lt = new Leaveteacher();
	Teacher t = new Teacher();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw = response.getWriter();
		
		String name1 = request.getParameter("name");
		String reason = request.getParameter("reason");
		String status = request.getParameter("status");
		
		t = bl.searchTeacherByName(name1);
		
		lt.setTeacher(t);
		lt.setReason(reason);
		lt.setStatus(status);
		
		bl.saveLeaveTeacher(lt);
		
		response.sendRedirect("PrincipalDashboard.jsp");
	}
}
