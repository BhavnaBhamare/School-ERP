package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Book;
import com.pojo.Bookissueteacher;
import com.pojo.Teacher;

/**
 * Servlet implementation class LibrarySaveBookIssueTeacher
 */
@WebServlet("/LibrarySaveBookIssueTeacher")
public class LibrarySaveBookIssueTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LibrarySaveBookIssueTeacher() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	Book b = new Book();
	Teacher t = new Teacher();
	Bookissueteacher bi1 = new Bookissueteacher();
	BLManager bl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String isbn = request.getParameter("isbn");
		String name = request.getParameter("name");
		String issuedate = request.getParameter("issuedate");
		String returndate = request.getParameter("returndate");

		b = bl.searchByBoookIsbn(isbn);
		t = bl.searchByTeachername(name);

		// b.setName(name);
		bi1.setIssuedate(issuedate);
		bi1.setReturndate(returndate);

		bi1.setBook(b);
		bi1.setTeacher(t);
		bl.SaveBookIssueTeacher(bi1);
		response.sendRedirect("LibraryAdminDashboard.jsp");
	}

}
