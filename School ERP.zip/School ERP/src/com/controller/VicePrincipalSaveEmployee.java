package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Employee;

/**
 * Servlet implementation class VicePrincipalSaveEmployee
 */
@WebServlet("/VicePrincipalSaveEmployee")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class VicePrincipalSaveEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	// private static final String SAV_DIR =
	// "D:/Jayesh/Practice/SCHOOL_MANAGEMENT/WebContent/photo";

	BLManager bl = new BLManager();
	Employee emp = new Employee();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		PrintWriter pw = response.getWriter();

		String name = request.getParameter("name");
		String position = request.getParameter("position");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String salary = request.getParameter("bed");
		String gender = request.getParameter("gender");
		String age = request.getParameter("age");
		String joindate = request.getParameter("joindate");
		String logname = request.getParameter("logname");
		String logpass = request.getParameter("logpass");
		// String aadhar = request.getParameter("aadhar");
		// String pan = request.getParameter("pan");
		String dob = request.getParameter("dob");

		Part img = request.getPart("photo");

		try {
			String Image1 = extractFileName(img);
			emp.setPhoto(Image1);
			img.write(SAV_DIR + File.separator + Image1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Part Aadhar = request.getPart("aadhar");
		try {
			String fileName = extractFileName1(Aadhar);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			emp.setAadhar(fileName);
			Aadhar.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part Pancade = request.getPart("pan");
		try {
			String fileName = extractFileName2(Pancade);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			emp.setPan(fileName);
			Pancade.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		emp.setName(name);
		emp.setPosition(position);
		emp.setPhone(phone);
		emp.setAddress(address);
		emp.setSalary(salary);
		emp.setGender(gender);
		emp.setAge(age);
		emp.setJoindate(joindate);
		emp.setLogname(logname);
		emp.setLogpass(logpass);
		emp.setDob(dob);

		bl.saveEmployee(emp);

		response.sendRedirect("VicePrincipalDashboard.jsp");

	}

	private String extractFileName(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName1(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName2(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}
}
