package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Bookissuestudent;

/**
 * Servlet implementation class LibraryDeleteBookIssueStudent
 */
@WebServlet("/LibraryDeleteBookIssueStudent")
public class LibraryDeleteBookIssueStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LibraryDeleteBookIssueStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

    Bookissuestudent bi=new Bookissuestudent();
   	BLManager bl=new BLManager();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String id=request.getParameter("bisid");
		int id1=Integer.parseInt(id);
		bi=bl.SearchBookIssueStudent(id1);
		bl.DeleteBookIssueStudent(bi);
		response.sendRedirect("LibraryAdminDashboard.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
