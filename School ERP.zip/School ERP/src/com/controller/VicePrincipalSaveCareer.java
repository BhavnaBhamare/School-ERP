package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Career;

@WebServlet("/VicePrincipalSaveCareer")
public class VicePrincipalSaveCareer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public VicePrincipalSaveCareer() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String post = request.getParameter("post");
		String discriptions = request.getParameter("discriptions");
		String package1 = request.getParameter("package_");

		Career c = new Career();

		c.setPost(post);
		c.setDiscriptions(discriptions);
		c.setPackage_(package1);

		BLManager b = new BLManager();
		b.saveCareer(c);

		response.sendRedirect("VicePrincipalDashboard.jsp");
	}

}
