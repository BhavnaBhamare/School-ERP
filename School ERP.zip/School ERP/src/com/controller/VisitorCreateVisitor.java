package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Visitors;

/**
 * Servlet implementation class VisitorCreateVisitor
 */
@WebServlet("/VisitorCreateVisitor")
public class VisitorCreateVisitor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisitorCreateVisitor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Visitors vistors = new Visitors();
	BLManager tbl = new BLManager();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String Name = request.getParameter("name");
		String Indate = request.getParameter("indate");
		String Intime = request.getParameter("intime");
		String Outdate = request.getParameter("outdate");
		String Outtime = request.getParameter("outtime");
		String Reason = request.getParameter("reason");
		String Address = request.getParameter("address");
		String Phone = request.getParameter("phone");
		String Idproof = request.getParameter("idproof");

		vistors.setName(Name);
		vistors.setIndate(Indate);
		vistors.setIntime(Intime);
		vistors.setOutdate(Outdate);
		vistors.setOuttime(Outtime);
		vistors.setReason(Reason);
		vistors.setAddress(Address);
		vistors.setPhone(Phone);
		vistors.setIdproof(Idproof);

		tbl.CreateVisitors(vistors);

		response.sendRedirect("VisitorDashboard.jsp");
	}


}
