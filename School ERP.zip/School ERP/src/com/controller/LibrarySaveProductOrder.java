package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Product;
import com.pojo.Productorder;

@WebServlet("/LibrarySaveProductOrder")
public class LibrarySaveProductOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LibrarySaveProductOrder() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String pname = request.getParameter("pname");
		String quantity = request.getParameter("quantity");
		String dateoforder = request.getParameter("dateoforder");

		Productorder p = new Productorder();
		BLManager bl = new BLManager();
		p.setPname(pname);
		p.setQuantity(quantity);
		p.setDateoforder(dateoforder);
		bl.saveOrderProduct(p);
		response.sendRedirect("LibraryAdminDashboard.jsp");

	}

}
