package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Sport;
import com.pojo.Tournament;
import com.pojo.Visitormeeting;
import com.pojo.Visitors;

/**
 * Servlet implementation class AddVisitorMeeting
 */
@WebServlet("/VisitorAddVisitorMeeting")
public class VisitorAddVisitorMeeting extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");		
        String time=request.getParameter("time");		
        String date=request.getParameter("date");		
        
            Visitormeeting v1=new Visitormeeting();
			BLManager bl=new BLManager();
			Visitors v=new Visitors();
			
		    v1.setDate(date);
			v1.setTime(time);
			v=bl.SearchByVisitorName(name);
            v1.setVisitors(v);
			
			bl.SaveVisitorsMeeting(v1);
			
			response.sendRedirect("VisitorDashboard.jsp");
	}

	}


