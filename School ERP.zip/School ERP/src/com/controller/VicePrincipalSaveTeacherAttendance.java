package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Teacher;
import com.pojo.Teacherattendance;

/**
 * Servlet implementation class CreateTeacherAttendance
 */
@WebServlet("/CreateTeacherAttendance")
public class VicePrincipalSaveTeacherAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VicePrincipalSaveTeacherAttendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	Teacher teacher = new Teacher();
	BLManager bl = new BLManager();
	Teacherattendance teacheratt = new Teacherattendance();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String Months = request.getParameter("months");
		String HalfDays = request.getParameter("halfdays");
		String FullDays = request.getParameter("fulldays");
		String AbsentDays = request.getParameter("absentdays");
		String TotalAbsentDays = request.getParameter("totalabsentdays");
		String Name = request.getParameter("name");

		teacher = bl.GetTeacherByName(Name);

//		teacheratt.setMonths(Months);
//		teacheratt.setHalfdays(HalfDays);
//		teacheratt.setFulldays(FullDays);
		teacheratt.setAbsentdays(AbsentDays);
//		teacheratt.setTotalabsentdays(TotalAbsentDays);
		teacheratt.setTeacher(teacher);

		bl.CreateTeacherattendance(teacheratt);

		response.sendRedirect("ViewTeacherAttendance.jsp");
	}

}
