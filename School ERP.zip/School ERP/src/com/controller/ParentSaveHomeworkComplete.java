package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Homework;
import com.pojo.Homeworkcomplete;
import com.pojo.Student;

/**
 * Servlet implementation class ParentSaveHomeworkComplete
 */
@WebServlet("/ParentSaveHomeworkComplete")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class ParentSaveHomeworkComplete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	BLManager bl = new BLManager();
	Homeworkcomplete hoc = new Homeworkcomplete();
	Homework ho = new Homework();
	Student s = new Student();

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String name = request.getParameter("name");
		String standard = request.getParameter("standard");
		String division = request.getParameter("division");
		
		Part file = request.getPart("file");
		
		try 
		{
			String file1 = extractFileName(file);
			hoc.setFile(file1);
			file.write(SAV_DIR + File.separator + file1);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		s = bl.searchbyStudent(name);
		
		ho = bl.searchbyStandard(standard);
		
		ho = bl.searchbyDivision(division);
		hoc.setStudent(s);
		hoc.setHomework(ho);
		
		
		bl.saveHomeWorkComplete(hoc);
		
		response.sendRedirect("ParentDashboard.jsp");
		
	}

	private String extractFileName(Part file) {
		String contentDisp = file.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) 
		{
			if (s.trim().startsWith("filename")) 
			{
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
