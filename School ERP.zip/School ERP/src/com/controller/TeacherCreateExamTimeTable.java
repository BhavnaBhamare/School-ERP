package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Examtimetable;

/**
 * Servlet implementation class TeacherCreateExamTimeTable
 */
@WebServlet("/TeacherCreateExamTimeTable")
public class TeacherCreateExamTimeTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherCreateExamTimeTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	Examtimetable examtimetable = new Examtimetable();
	BLManager bl = new BLManager();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String Standard = request.getParameter("standard");
		String Division = request.getParameter("division");
		String File = request.getParameter("file");
		String Year = request.getParameter("year");

		examtimetable.setStandard(Standard);
		examtimetable.setDivision(Division);
		examtimetable.setFile(File);
		examtimetable.setYear(Year);

		bl.CreateExamtimetable(examtimetable);

		response.sendRedirect("TeacherDashboard.jsp");

	}

}
