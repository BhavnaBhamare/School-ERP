package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Leaveemployee;

/**
 * Servlet implementation class PrincipalUpdateLeaveEmployeeServlet
 */
@WebServlet("/PrincipalUpdateLeaveEmployeeServlet")
public class PrincipalUpdateLeaveEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrincipalUpdateLeaveEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    Leaveemployee lemp = new Leaveemployee();
	BLManager bl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String leaveeid1 = request.getParameter("leaveeid");
		int id1 = Integer.parseInt(leaveeid1);
		
		lemp = bl.searchbyId1(id1);
		
		HttpSession session = request.getSession();
		session.setAttribute("list", lemp);
		
		response.sendRedirect("PrincipalUpdateLeavesEmployee.jsp");
		
		
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
