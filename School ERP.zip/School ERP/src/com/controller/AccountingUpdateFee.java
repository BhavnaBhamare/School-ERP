package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Fee;

/**
 * Servlet implementation class AccountingUpdateFee
 */
@WebServlet("/AccountingUpdateFee")
public class AccountingUpdateFee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AccountingUpdateFee() {
		super();
		// TODO Auto-generated constructor stub
	}

	Fee fee = new Fee();
	BLManager feebl = new BLManager();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Id = request.getParameter("fsid");
		int ID = Integer.parseInt(Id);

		fee = feebl.GetFeeById(ID);

		HttpSession session = request.getSession();
		session.setAttribute("list", fee);

		response.sendRedirect("AccountingUpdateFee.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {

		String year = request.getParameter("year");
		String standard = request.getParameter("standard");

		String tuitionfees = request.getParameter("tuitionfees");
		int tf = Integer.parseInt(tuitionfees);

		String transport = request.getParameter("transport");
		int tr = Integer.parseInt(transport);

		String hostel = request.getParameter("hostel");
		int ho = Integer.parseInt(hostel);

		String library = request.getParameter("library");
		int li = Integer.parseInt(library);

		String sport = request.getParameter("sport");
		int sp = Integer.parseInt(sport);

		String exam = request.getParameter("exams");
		int ex = Integer.parseInt(exam);

		String other = request.getParameter("other");
		int ot = Integer.parseInt(other);

		// String total = request.getParameter("totalfee");

		int to = tf + tr + ho + li + sp + ex + ot;

		String totalfee = String.valueOf(to);

		fee.setYear(year);
		fee.setStandard(standard);
		fee.setTuitionfees(tuitionfees);
		fee.setTransport(transport);
		fee.setHostel(hostel);
		fee.setLibrary(library);
		fee.setSport(sport);
		fee.setExam(exam);
		fee.setOther(other);
		fee.setTotalfee(totalfee);

		feebl.UpdateFee(fee);

		response.sendRedirect("AccountingDashboard.jsp");
	}

}
