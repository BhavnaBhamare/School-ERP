package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Reviewstudent;
import com.pojo.Student;

/**
 * Servlet implementation class StudentUpdateReview
 */
@WebServlet("/StudentUpdateReviewStudent")
public class StudentUpdateReviewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	BLManager bl = new BLManager();
	Reviewstudent rs = new Reviewstudent();
	Student s = new Student();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("reviewstudid");
		int id = Integer.parseInt(id1);
		rs = bl.SearchByRSId(id);
		// System.out.println(d);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", rs);

		response.sendRedirect("StudentUpdateReviewStudent.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		int seid = Integer.parseInt(request.getParameter("reviewstudid"));

		String name = request.getParameter("name");

		// int sid=Integer.parseInt(request.getParameter("sid"));
		String comment = request.getParameter("comment");

		rs.setReviewstudid(seid);
		s = bl.serachByStudName(name);
		rs.setStudent(s);
		rs.setComment(comment);

		bl.updateReview(rs);
		response.sendRedirect("StudentDashboard.jsp");
	}

}
