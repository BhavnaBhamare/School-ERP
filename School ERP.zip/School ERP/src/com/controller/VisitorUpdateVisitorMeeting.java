package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Visitormeeting;
import com.pojo.Visitors;

/**
 * Servlet implementation class VisitorViewVisitorMeeting
 */
@WebServlet("/VisitorUpdateVisitorMeeting")
public class VisitorUpdateVisitorMeeting extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisitorUpdateVisitorMeeting() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    Visitormeeting v=new Visitormeeting();
   	BLManager bl=new BLManager();
   	Visitors v1=new Visitors();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String id=request.getParameter("vmid");
		int id1=Integer.parseInt(id);
		v = bl.SearchVisitorsMeetingById(id1);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", v);
		
		response.sendRedirect("VisitorUpdateVisitorMeeting.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		String time=request.getParameter("time");
		String date=request.getParameter("date");
		
		v1=bl.SearchByVisitorName(name);
		
		v.setTime(time);
		v.setDate(date);
		v.setVisitors(v1);
		
		bl.UpdateVisitorMeeting(v);
		response.sendRedirect("VicePrincipalDashboard.jsp");
	}

}
