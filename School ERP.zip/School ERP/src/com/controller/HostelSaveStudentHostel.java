package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Hostel;

/**
 * Servlet implementation class HostelSaveStudentHostel
 */
@WebServlet("/HostelSaveStudentHostel")
public class HostelSaveStudentHostel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HostelSaveStudentHostel() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Hostel ho = new Hostel();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String type = request.getParameter("type");
		String wardenname = request.getParameter("wardenname");
		String wing = request.getParameter("wing");
		String room = request.getParameter("room");
		String bed = request.getParameter("bed");
		String watertime = request.getParameter("watertime");
		String breakfasttime = request.getParameter("breakfasttime");
		String lunchtime = request.getParameter("lunchtime");
		String dinnertime = request.getParameter("dinnertime");
		String logname = request.getParameter("logname");
		String logpass = request.getParameter("logpass");
		String finalintime = request.getParameter("finalintime");
		
		ho.setType(type);
		ho.setWardenname(wardenname);
		ho.setWing(wing);
		ho.setRoom(room);
		ho.setBed(bed);
		ho.setWatertime(watertime);
		ho.setBreakfasttime(breakfasttime);
		ho.setLunchtime(lunchtime);
		ho.setDinnertime(dinnertime);
		ho.setLogname(logname);
		ho.setLogpass(logpass);
		ho.setFinalintime(finalintime);
		
		bl.CreateHostel(ho);
		
		
		pw.println("<script type = \"text/javascript\">");
		pw.println("alert('Hostel Recorded');");
		pw.println("location='HostelAdminDashboard.jsp'; ");
		pw.println("</script>");
	}


}
