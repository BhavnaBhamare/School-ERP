package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Offlineexam;
import com.pojo.Subject;
import com.pojo.Testseries;

/**
 * Servlet implementation class TeacherAddOfflineExam
 */
@WebServlet("/TeacherAddOfflineExam")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class TeacherAddOfflineExam extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherAddOfflineExam() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	private static final String SAV_DIR = "";

	Testseries ts = new Testseries();
	Subject s = new Subject();
	BLManager bl = new BLManager();
	Offlineexam oe = new Offlineexam();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		PrintWriter pw = response.getWriter();

		String tsname = request.getParameter("tsname");
		String standard = request.getParameter("standard");
		String division = request.getParameter("division");
		String subname = request.getParameter("subname");

		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String submittime = request.getParameter("submittime");
		Part file = request.getPart("file");
		try {
			String fileName = extractFileName(file);
			String path = getServletContext().getRealPath(SAV_DIR + File.separator + fileName);
			oe.setFile(fileName);
			file.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ts = bl.searchByTestseriesname(tsname);

		s = bl.searchbySubname(subname);

		oe.setTestseries(ts);
		oe.setStandard(standard);
		oe.setDivision(division);
		oe.setSubject(s);
		oe.setDate(date);
		oe.setTime(time);
		oe.setSubmittime(submittime);

		bl.saveOfflineExam(oe);

		response.sendRedirect("TeacherDashboard.jsp");

	}

	private String extractFileName(Part file) {
		String contentDisp = file.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
