package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Hostel;
import com.pojo.Student;
import com.pojo.Studenthostel;

/**
 * Servlet implementation class HostelUpdateStudentHostel
 */
@WebServlet("/HostelUpdateStudentHostel")
public class HostelUpdateStudentHostel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HostelUpdateStudentHostel() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		Student student = new Student();
		Hostel hostel = new Hostel();
		BLManager bl = new BLManager();
		Studenthostel studenthostel = new Studenthostel();

		String SHId = request.getParameter("shid");
		int shID = Integer.parseInt(SHId);
		String BedNo = request.getParameter("bedno");
		String RoomNo = request.getParameter("roomno");
		String Name = request.getParameter("name");
		String Wing = request.getParameter("wing");

		student = bl.GetStudentByName(Name);
		hostel = bl.GetHostelByBed(Wing);

		studenthostel.setShid(shID);
		studenthostel.setBedno(BedNo);
		studenthostel.setRoomno(RoomNo);
		studenthostel.setHostel(hostel);
		studenthostel.setStudent(student);

		bl.UpdateStudentHostel(studenthostel);

		response.sendRedirect("HostelAdminDashboard.jsp");
	}

}
