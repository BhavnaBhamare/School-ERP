package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Fee;

/**
 * Servlet implementation class AccountingAddFees
 */
@WebServlet("/AccountingAddFees")
public class AccountingAddFees extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountingAddFees() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Fee fe = new Fee();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String year = request.getParameter("year");
		String standard = request.getParameter("standard");
		
		String tuitionfees = request.getParameter("tuitionfees");
		int tf = Integer.parseInt(tuitionfees);
		
		String transport = request.getParameter("transport");
		int tr = Integer.parseInt(transport);
		
		String hostel = request.getParameter("hostel");
		int h = Integer.parseInt(hostel);
		
		String library = request.getParameter("library");
		int lb = Integer.parseInt(library);
		
		String sport = request.getParameter("sport");
		int sp = Integer.parseInt(sport);
		
		String exam = request.getParameter("exams");
		int ex = Integer.parseInt(exam);
		
		String other = request.getParameter("other");
		int ot = Integer.parseInt(other);
		
		System.out.println(ot);
		
		int tof = tf + tr + h + lb + sp + ex + ot;
		
		System.out.println(tof);
		
		String totalfee = String.valueOf(tof);

		fe.setYear(year);
		fe.setStandard(standard);
		fe.setTuitionfees(tuitionfees);
		fe.setTransport(transport);
		fe.setHostel(hostel);
		fe.setLibrary(library);
		fe.setSport(sport);
		fe.setExam(exam);
		fe.setOther(other);
		fe.setTotalfee(totalfee);
		
		bl.CreateFee(fe);
		
		response.sendRedirect("AccountingDashboard.jsp");
	}

}
