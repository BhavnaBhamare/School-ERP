package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Book;
import com.pojo.Subject;

/**
 * Servlet implementation class LibraryUpdateBook
 */
@WebServlet("/LibraryUpdateBook")
public class LibraryUpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	Book b = new Book();
	BLManager bl = new BLManager();

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String id = request.getParameter("bookid");
		int id1 = Integer.parseInt(id);
		b = bl.SearchBookById(id1);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", b);

		response.sendRedirect("LibraryUpdateBook.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String name = request.getParameter("name");
		String catagery = request.getParameter("catagery");
		String std = request.getParameter("standard");
		String subname = request.getParameter("subname");
		String author = request.getParameter("author");
		String isbn = request.getParameter("isbn");
		String page = request.getParameter("page");
		String price = request.getParameter("price");
		String quantity = request.getParameter("quantity");
		String language = request.getParameter("language");
		String publication = request.getParameter("publication");

		Subject s = new Subject();

		b.setName(name);
		b.setCatagery(catagery);
		b.setStandard(std);
		b.setAuthor(author);
		b.setAuthor(author);
		b.setIsbn(isbn);
		b.setPage(page);
		b.setPrice(price);
		b.setQuantity(quantity);
		b.setLanguage(language);
		b.setPublication(publication);

		s = bl.searchbySubName(subname);
		b.setSubject(s);

		bl.updateBook(b);
		response.sendRedirect("LibraryAdminDashboard.jsp");
	}

}
