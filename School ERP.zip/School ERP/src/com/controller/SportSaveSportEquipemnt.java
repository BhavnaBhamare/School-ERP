package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Sport;
import com.pojo.Sportequipment;

/**
 * Servlet implementation class SportSaveSportEquipemnt
 */
@WebServlet("/SportSaveSportEquipemnt")
public class SportSaveSportEquipemnt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SportSaveSportEquipemnt() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Sportequipment p = new Sportequipment();
	BLManager bl = new BLManager();
	Sport sp = new Sport();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String sportname = request.getParameter("sportname");
		String ename = request.getParameter("ename");
		String quantity = request.getParameter("quantity");

		sp = bl.SearchBySName(sportname);

		p.setEname(ename);
		p.setQuantity(quantity);
		p.setSport(sp);

		bl.saveSportEquipment(p);
		response.sendRedirect("SportDashboard.jsp");
	}

}
