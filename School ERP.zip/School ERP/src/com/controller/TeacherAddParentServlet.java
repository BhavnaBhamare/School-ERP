package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Parent;

/**
 * Servlet implementation class TeacherAddParentServlet
 */
@WebServlet("/TeacherAddParentServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class TeacherAddParentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherAddParentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	private static final String SAV_DIR = "";
	BLManager bl = new BLManager();
	Parent p = new Parent();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String fathername = request.getParameter("fathername");
		String mothername = request.getParameter("mothername");
		String fphone = request.getParameter("fphone");
		String mphone = request.getParameter("mphone");
		String address = request.getParameter("address");
		String occupation = request.getParameter("occupation");
		String logname = request.getParameter("logname");
		String logpass = request.getParameter("logpass");
		String altphoneno = request.getParameter("altphoneno");

		Part fatherphoto = request.getPart("fatherphoto");
		Part motherphoto = request.getPart("motherphoto");

		try {
			String fatherphoto1 = extractFileName(fatherphoto);
			String motherphoto1 = extractFileName1(motherphoto);
			p.setFatherphoto(fatherphoto1);
			p.setMotherphoto(motherphoto1);
			fatherphoto.write(SAV_DIR + File.separator + fatherphoto1);
			motherphoto.write(SAV_DIR + File.separator + motherphoto1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String accno = request.getParameter("accno");
		String ifsc = request.getParameter("ifsc");
		String accholdername = request.getParameter("accholdername");

		p.setFathername(fathername);
		p.setMothername(mothername);
		p.setFphone(fphone);
		p.setMphone(mphone);
		p.setAddress(address);
		p.setOccupation(occupation);
		p.setLogname(logname);
		p.setLogpass(logpass);
		p.setAltphoneno(altphoneno);
		p.setAccno(accno);
		p.setIfsc(ifsc);
		p.setAccholdername(accholdername);

		bl.CreateParent(p);

		response.sendRedirect("TeacherDashboard.jsp");

	}

	private String extractFileName1(Part motherphoto) {
		String contentDisp = motherphoto.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

	private String extractFileName(Part fatherphoto) {
		String contentDisp = fatherphoto.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
