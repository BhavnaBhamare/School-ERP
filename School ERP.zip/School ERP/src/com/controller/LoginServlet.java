package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Admin;
import com.pojo.Employee;
import com.pojo.Parent;
import com.pojo.Student;
import com.pojo.Teacher;

/**
 * Servlet implementation class StudentLogin
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Student student = new Student();
	Teacher teacher = new Teacher();
	Employee emp = new Employee();
	Admin admin = new Admin();
	BLManager bl = new BLManager();
	Parent parent= new Parent();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String post = request.getParameter("post");
		String username = request.getParameter("logname");
		String password = request.getParameter("logpass");

		if (post.equals("Student")) {
			student = bl.StudentLogin(username, password);
			if (student != null) {
				HttpSession s = request.getSession();
				s.setAttribute("sid", student.getSid());
				s.setAttribute("currentUser", student);
				RequestDispatcher rd = request.getRequestDispatcher("StudentDashboard.jsp");
				rd.forward(request, response);
			}
		}
		if (post.equals("Teacher")) {
			teacher = bl.TeacherLogin(username, password);
			if (teacher != null) {
				HttpSession s = request.getSession();
				s.setAttribute("currentUser", teacher);
				RequestDispatcher rd = request.getRequestDispatcher("TeacherDashboard.jsp");
				rd.forward(request, response);
			}
		}
		if (post.equals("Employee")) {
			emp = bl.EmployeeLogin(username, password);
			if (emp != null) {
				HttpSession s = request.getSession();
				s.setAttribute("currentUser", emp);
				RequestDispatcher rd = request.getRequestDispatcher("EmployeeDashboard.jsp");
				rd.forward(request, response);
			}
		}
		if (post.equals("Admin")) {
			admin = bl.AdminLogin(username, password);
			if (admin != null) {
				HttpSession s = request.getSession();
				s.setAttribute("currentUser", parent);
				RequestDispatcher rd = request.getRequestDispatcher("Login1.jsp");
				rd.forward(request, response);
			}
		}
		if (post.equals("Parent")) {
			parent = bl.ParentLogin(username, password);
			if (parent != null) {
				HttpSession s = request.getSession();
				s.setAttribute("currentUser", parent);
				RequestDispatcher rd = request.getRequestDispatcher("ParentDashboard.jsp");
				rd.forward(request, response);
			}
		}
		else {
			response.sendRedirect("Admission.jsp");
		}
	}

}
