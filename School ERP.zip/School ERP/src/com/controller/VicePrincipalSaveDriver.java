package com.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Driver;

/**
 * Servlet implementation class VicePrincipalSaveDriver
 */
@WebServlet("/VicePrincipalSaveDriver")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 100, // 10MB
maxRequestSize = 1024 * 1024 * 500)
public class VicePrincipalSaveDriver extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";
	private static final String SAV_DIR1 = "";
	private static final String SAV_DIR2 = "";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VicePrincipalSaveDriver() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	Driver d = new Driver();

	BLManager bl = new BLManager();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		String dname = request.getParameter("dname");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String position = request.getParameter("position");
		String gender = request.getParameter("gender");
		String age = request.getParameter("age");
		String licenceno = request.getParameter("licenceno");
		String logname = request.getParameter("logname");
		String logpass = request.getParameter("logpass");
		String salary = request.getParameter("salary");

		Part photo = request.getPart("photo");
		try {
			String fileName = extractFileName(photo);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			d.setPhoto(fileName);
			photo.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part aadhar = request.getPart("aadhar");
		try {
			String fileName = extractFileName(aadhar);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			d.setAadhar(fileName);
			aadhar.write(SAV_DIR1 + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Part panno = request.getPart("panno");
		try {
			String fileName = extractFileName(panno);
			// String path = getServletContext().getRealPath(SAV_DIR +
			// File.separator + fileName);
			d.setAadhar(fileName);
			panno.write(SAV_DIR2 + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		d.setDname(dname);
		d.setAddress(address);
		d.setPhone(phone);
		d.setPosition(position);
		d.setGender(gender);
		d.setAge(age);
		d.setLicenceno(licenceno);
		d.setLogname(logname);
		d.setLogpass(logpass);
		d.setSalary(salary);

		bl.saveDriver(d);

		response.sendRedirect("VicePrincipalDashboard.jsp");
	}

	private String extractFileName(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}
}
