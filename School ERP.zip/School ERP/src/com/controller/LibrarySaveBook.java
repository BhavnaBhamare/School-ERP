package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Book;
import com.pojo.Subject;

/**
 * Servlet implementation class LibrarySaveBook
 */
@WebServlet("/LibrarySaveBook")
public class LibrarySaveBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LibrarySaveBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/// doGet(request, response);
		String name = request.getParameter("name");
		String catagery = request.getParameter("catagery");
		String std = request.getParameter("standard");
		String subname = request.getParameter("subname");
		String author = request.getParameter("author");
		String isbn = request.getParameter("isbn");
		String page = request.getParameter("page");
		String price = request.getParameter("price");
		String quantity = request.getParameter("quantity");
		String language = request.getParameter("language");
		String publication = request.getParameter("publication");

		Book b = new Book();
		BLManager bl = new BLManager();
		Subject s = new Subject();

		b.setName(name);
		b.setCatagery(catagery);
		b.setStandard(std);
		b.setAuthor(author);
		b.setIsbn(isbn);
		b.setPage(page);
		b.setPrice(price);
		b.setQuantity(quantity);
		b.setLanguage(language);
		b.setPublication(publication);

		s = bl.searchbySubName(subname);
		b.setSubject(s);

		bl.saveBook(b);

		response.sendRedirect("LibraryAdminDashboard.jsp");
	}

}
