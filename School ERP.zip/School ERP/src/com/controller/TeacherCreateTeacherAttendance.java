package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BLManager;
import com.pojo.Lectureattendance;
import com.pojo.Subject;
import com.pojo.Teacher;

/**
 * Servlet implementation class TeacherCreateTeacherAttendance
 */
@WebServlet("/TeacherCreateTeacherAttendance")
public class TeacherCreateTeacherAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TeacherCreateTeacherAttendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	BLManager bl = new BLManager();
	Lectureattendance lat = new Lectureattendance();
	Subject s = new Subject();
	Teacher t = new Teacher();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {

		String dates = request.getParameter("dates");
		String hours = request.getParameter("hours");
		String standard = request.getParameter("standard");
		String division = request.getParameter("division");
		String subname = request.getParameter("subname");
		String name = request.getParameter("name");
		String rollnospresents = request.getParameter("rollnospresents");
		String rollnoabsents = request.getParameter("rollnoabsents");

		s = bl.searchbySubname(subname);
		t = bl.searchTeacherByName(name);

		lat.setDates(dates);
		lat.setHours(hours);
		lat.setStandard(standard);
		lat.setDivision(division);
		lat.setSubject(s);
		lat.setTeacher(t);
		lat.setRollnospresents(rollnospresents);
		lat.setRollnoabsents(rollnoabsents);

		bl.saveLectureAttendance(lat);
		
		response.sendRedirect("TeacherDashboard.jsp");
	}

}
