package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.model.BLManager;
import com.pojo.Announcement;

/**
 * Servlet implementation class PrincipalUpdateAnnouncement
 */
@WebServlet("/PrincipalUpdateAnnouncement")
public class PrincipalUpdateAnnouncement extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SAV_DIR = "";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrincipalUpdateAnnouncement() {
        super();
        // TODO Auto-generated constructor stub
    }

    Announcement a=new Announcement();
   	BLManager bl=new BLManager();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id=request.getParameter("annid");
		int id1=Integer.parseInt(id);
		a = bl.SearchByAnnouncementId(id1);

		HttpSession ses = request.getSession();
		ses.setAttribute("list", a);
		
		response.sendRedirect("PrincipalUpdateAnnouncement.jsp");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String announcement = request.getParameter("announcement");
		String dateofann = request.getParameter("dateofann");

		a.setAnnouncement(announcement);
		a.setDateofann(dateofann);

		Part filePart = request.getPart("file");
		try {
			String fileName = extractFileName(filePart);
//			String path = getServletContext().getRealPath(SAV_DIR + File.separator + fileName);
			a.setFile(fileName);
			filePart.write(SAV_DIR + File.separator + fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		bl.saveAnnouncement(a);
		InputStream is = filePart.getInputStream();
		response.sendRedirect("PrincpalDashboard.jsp");

	}

	private String extractFileName(Part img) {
		String contentDisp = img.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
