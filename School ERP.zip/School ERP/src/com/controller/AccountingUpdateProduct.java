package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Product;

/**
 * Servlet implementation class AccountingUpdateProduct
 */
@WebServlet("/AccountingUpdateProduct")
public class AccountingUpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	Product p=new Product();
    BLManager bl=new BLManager();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("pid");
		int id = Integer.parseInt(id1);
		p = bl.SearchByPId(id);
		

		HttpSession ses = request.getSession();
		ses.setAttribute("list", p);

		response.sendRedirect("AccountingUpdateProduct.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String did = request.getParameter("pid");
		int id = Integer.parseInt(did);
		String pname=request.getParameter("pname");
		String quantity=request.getParameter("quantity");
		String department=request.getParameter("department");
	
	
		p.setPid(id);
		p.setPname(pname);
		p.setQuantity(quantity);
		p.setDepartment(department);
		bl.updateProduct(p);
	    response.sendRedirect("AccountingDashboard.jsp");
	}


}
